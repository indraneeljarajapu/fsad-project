package com.hospital.enums;


public enum Role {
    PATIENT,
    DOCTOR,
    NURSE,
    STAFF,
    ADMIN // Example roles
}
