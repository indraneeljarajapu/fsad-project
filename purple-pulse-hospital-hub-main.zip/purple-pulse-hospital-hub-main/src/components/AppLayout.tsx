
import { useState, useEffect } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { 
  Home, 
  User, 
  Calendar, 
  Clock, 
  FileText, 
  Settings, 
  Users, 
  Heart, 
  LogOut,
  Menu,
  X,
  Bell
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface AppLayoutProps {
  children: React.ReactNode;
}

const AppLayout: React.FC<AppLayoutProps> = ({ children }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) {
        setIsSidebarOpen(false);
        setIsMobile(true);
      } else {
        setIsSidebarOpen(true);
        setIsMobile(false);
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Determine navigation links based on user role
  const getNavLinks = () => {
    if (!user) return [];

    switch (user.role) {
      case 'patient':
        return [
          { icon: Home, label: 'Dashboard', href: '/patient-dashboard' },
          { icon: Calendar, label: 'Appointments', href: '/patient-appointments' },
          { icon: FileText, label: 'Health Records', href: '/patient-records' },
          { icon: User, label: 'Profile', href: '/patient-profile' },
        ];
      case 'doctor':
        return [
          { icon: Home, label: 'Dashboard', href: '/doctor-dashboard' },
          { icon: Users, label: 'Patients', href: '/doctor-patients' },
          { icon: Clock, label: 'Shifts', href: '/doctor-shifts' },
          { icon: User, label: 'Profile', href: '/doctor-profile' },
        ];
      case 'admin':
        return [
          { icon: Home, label: 'Dashboard', href: '/admin-dashboard' },
          { icon: Users, label: 'Staff', href: '/admin-staff' },
          { icon: Users, label: 'Patients', href: '/admin-patients' },
          { icon: Settings, label: 'Hospital Settings', href: '/admin-settings' },
        ];
      default:
        return [];
    }
  };

  const navLinks = getNavLinks();

  return (
    <div className="min-h-screen bg-hospital-soft-gray bg-hospital-pattern">
      {/* Mobile Header */}
      <header className="md:hidden bg-white shadow-sm py-3 px-4 flex items-center justify-between sticky top-0 z-10">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
        >
          {isSidebarOpen ? <X size={20} /> : <Menu size={20} />}
        </Button>
        
        <h1 className="text-xl font-bold text-hospital-purple">MediCare</h1>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="rounded-full">
              <User size={20} />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel className="font-normal">
              <div className="flex flex-col space-y-1">
                <p className="font-medium leading-none">{user?.name}</p>
                <p className="text-sm leading-none text-muted-foreground">
                  {user?.email}
                </p>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => logout()}>
              <LogOut className="mr-2 h-4 w-4" />
              <span>Log out</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </header>

      {/* Sidebar and Content Layout */}
      <div className="flex min-h-screen">
        {/* Sidebar */}
        <aside
          className={cn(
            "bg-white border-r border-hospital-light-purple/30 h-screen fixed md:sticky top-0 left-0 z-30 w-64 transition-all duration-300 ease-in-out flex flex-col",
            isSidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0 md:w-16"
          )}
        >
          {/* Sidebar Header */}
          <div className="p-4 border-b border-hospital-light-purple/30 flex items-center justify-between">
            {(!isMobile || isSidebarOpen) && (
              <Link to="/" className="flex items-center">
                <Heart className="h-6 w-6 text-hospital-purple mr-2" />
                {(!isMobile || isSidebarOpen) && !isMobile && (
                  <span className="font-bold text-lg text-hospital-purple">MediCare</span>
                )}
              </Link>
            )}
            {!isMobile && (
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => setIsSidebarOpen(!isSidebarOpen)} 
                className="ml-auto"
              >
                {isSidebarOpen ? <X size={16} /> : <Menu size={16} />}
              </Button>
            )}
          </div>

          {/* Navigation Links */}
          <nav className="flex-1 overflow-y-auto py-4">
            <ul className="space-y-1 px-2">
              {navLinks.map((link) => {
                const isActive = location.pathname === link.href;
                return (
                  <li key={link.href}>
                    <Link
                      to={link.href}
                      className={cn(
                        "flex items-center py-2 px-3 rounded-md transition-colors",
                        isActive
                          ? "bg-hospital-light-purple/20 text-hospital-purple"
                          : "hover:bg-hospital-light-purple/10 text-gray-600 hover:text-hospital-purple"
                      )}
                    >
                      <link.icon className="h-5 w-5 mr-3 flex-shrink-0" />
                      {(!isMobile || isSidebarOpen) && !isMobile && (
                        <span>{link.label}</span>
                      )}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </nav>

          {/* Sidebar Footer with User Info */}
          <div className="border-t border-hospital-light-purple/30 p-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="w-full flex items-center justify-start p-2 text-left">
                  <div className="h-8 w-8 rounded-full bg-hospital-purple/20 flex items-center justify-center text-hospital-purple mr-2 flex-shrink-0">
                    {user?.name.charAt(0)}
                  </div>
                  {(!isMobile || isSidebarOpen) && !isMobile && (
                    <div className="overflow-hidden">
                      <p className="font-medium truncate">{user?.name}</p>
                      <p className="text-xs text-gray-500 capitalize">{user?.role}</p>
                    </div>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-56">
                <DropdownMenuLabel>
                  <div className="flex flex-col space-y-1">
                    <p className="font-medium leading-none">{user?.name}</p>
                    <p className="text-xs leading-none text-muted-foreground capitalize">
                      {user?.role}
                    </p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => navigate(`/${user?.role}-profile`)}>
                  <User className="mr-2 h-4 w-4" />
                  <span>My Profile</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => logout()}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </aside>

        {/* Main Content */}
        <main className={cn(
          "flex-1 p-4 md:p-6 transition-all duration-300",
          isSidebarOpen && !isMobile ? "md:ml-64" : ""
        )}>
          {/* Top Nav for Desktop */}
          <header className="hidden md:flex justify-between items-center mb-6 bg-white rounded-lg p-3 shadow-sm">
            <h1 className="text-2xl font-bold text-hospital-purple">
              {user && `${user.role.charAt(0).toUpperCase() + user.role.slice(1)} Dashboard`}
            </h1>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="icon">
                <Bell className="h-5 w-5" />
              </Button>
              <Button onClick={() => logout()} variant="outline" className="flex items-center">
                <LogOut className="h-5 w-5 mr-2" />
                Logout
              </Button>
            </div>
          </header>
          
          {/* Page Content */}
          <div className="animate-fade-in">{children}</div>
        </main>

        {/* Sidebar Overlay for Mobile */}
        {isMobile && isSidebarOpen && (
          <div 
            className="fixed inset-0 bg-black/50 z-20"
            onClick={() => setIsSidebarOpen(false)}
          />
        )}
      </div>
    </div>
  );
};

export default AppLayout;
