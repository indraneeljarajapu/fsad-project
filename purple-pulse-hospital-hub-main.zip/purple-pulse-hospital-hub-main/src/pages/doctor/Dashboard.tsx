
import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Users, Calendar, Clock, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { mockAppointments, mockPatients } from '@/lib/mockData';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// Chart data
const appointmentData = [
  { name: 'Mon', appointments: 5 },
  { name: 'Tue', appointments: 8 },
  { name: 'Wed', appointments: 6 },
  { name: 'Thu', appointments: 9 },
  { name: 'Fri', appointments: 7 },
  { name: 'Sat', appointments: 3 },
  { name: 'Sun', appointments: 0 },
];

const DoctorDashboard = () => {
  const { user } = useAuth();
  
  // Filter appointments for current doctor
  const doctorAppointments = mockAppointments.filter(
    (appointment) => appointment.doctorId === '1'
  );

  const upcomingAppointments = doctorAppointments.filter(
    (appointment) => appointment.status === 'scheduled'
  );
  
  const todaysAppointments = upcomingAppointments.filter(
    (appointment) => {
      // In a real app, we'd check if the date is today
      // For simplicity, we'll just take the first few appointments
      return true;
    }
  ).slice(0, 3);

  return (
    <div className="space-y-6">
      {/* Welcome & Quick Stats */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="hospital-card bg-gradient-to-br from-hospital-purple to-hospital-light-purple text-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-white text-xl">Welcome Back</CardTitle>
            <CardDescription className="text-white text-opacity-90">
              {user?.name}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-lg font-semibold">You have {todaysAppointments.length} appointments today</p>
          </CardContent>
          <CardFooter>
            <Button asChild variant="secondary" className="w-full text-hospital-purple">
              <Link to="/doctor-appointments">View Schedule</Link>
            </Button>
          </CardFooter>
        </Card>

        {/* Quick Stats */}
        <Card className="hospital-card">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Patients</CardTitle>
            <Users className="h-4 w-4 text-hospital-purple" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">42</div>
            <p className="text-xs text-muted-foreground">
              +5 new this month
            </p>
          </CardContent>
          <CardFooter className="p-2">
            <Link 
              to="/doctor-patients" 
              className="text-xs text-hospital-purple hover:underline w-full text-right"
            >
              View all patients
            </Link>
          </CardFooter>
        </Card>

        <Card className="hospital-card">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Today's Appointments</CardTitle>
            <Calendar className="h-4 w-4 text-hospital-purple" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{todaysAppointments.length}</div>
            <p className="text-xs text-muted-foreground">
              Next at {todaysAppointments[0]?.time || 'N/A'}
            </p>
          </CardContent>
          <CardFooter className="p-2">
            <Link 
              to="/doctor-appointments" 
              className="text-xs text-hospital-purple hover:underline w-full text-right"
            >
              View schedule
            </Link>
          </CardFooter>
        </Card>

        <Card className="hospital-card">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Working Hours</CardTitle>
            <Clock className="h-4 w-4 text-hospital-purple" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">32h</div>
            <p className="text-xs text-muted-foreground">
              This week
            </p>
          </CardContent>
          <CardFooter className="p-2">
            <Link 
              to="/doctor-shifts" 
              className="text-xs text-hospital-purple hover:underline w-full text-right"
            >
              View shifts
            </Link>
          </CardFooter>
        </Card>
      </div>

      {/* Chart & Today's Appointments */}
      <div className="grid gap-6 md:grid-cols-3">
        <div className="md:col-span-2">
          <Card className="hospital-card">
            <CardHeader>
              <CardTitle>Weekly Appointments</CardTitle>
              <CardDescription>Appointments overview for the current week</CardDescription>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart
                    data={appointmentData}
                    margin={{ top: 20, right: 30, left: 0, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient id="colorAppointments" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#9b87f5" stopOpacity={0.8} />
                        <stop offset="95%" stopColor="#9b87f5" stopOpacity={0.1} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} />
                    <YAxis axisLine={false} tickLine={false} />
                    <Tooltip />
                    <Area 
                      type="monotone" 
                      dataKey="appointments" 
                      stroke="#9b87f5" 
                      fillOpacity={1} 
                      fill="url(#colorAppointments)" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Today's Appointments */}
        <div>
          <Card className="hospital-card">
            <CardHeader>
              <CardTitle>Today's Schedule</CardTitle>
              <CardDescription>Upcoming appointments for today</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {todaysAppointments.length > 0 ? (
                todaysAppointments.map((appointment, index) => {
                  const patient = mockPatients.find(p => p.id === appointment.patientId);
                  return (
                    <div 
                      key={appointment.id} 
                      className={`flex items-center p-3 ${
                        index !== todaysAppointments.length - 1 ? 'border-b pb-4' : ''
                      }`}
                    >
                      <div className="h-10 w-10 rounded-full bg-hospital-light-purple/30 flex items-center justify-center mr-3">
                        <User className="h-5 w-5 text-hospital-purple" />
                      </div>
                      <div>
                        <p className="font-medium">{patient?.name}</p>
                        <div className="flex items-center gap-3">
                          <div className="flex items-center">
                            <Clock className="h-3 w-3 text-gray-400 mr-1" />
                            <span className="text-xs text-gray-500">{appointment.time}</span>
                          </div>
                          <span className="text-xs px-2 py-0.5 rounded bg-blue-100 text-blue-700">
                            {appointment.status}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500">No appointments scheduled for today</p>
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline" className="w-full">
                <Link to="/doctor-appointments">View All Appointments</Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
      
      {/* Recent Patients */}
      <Card className="hospital-card">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Recent Patients</CardTitle>
            <CardDescription>Your recently treated patients</CardDescription>
          </div>
          <Button asChild variant="outline" size="sm">
            <Link to="/doctor-patients">View All</Link>
          </Button>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {mockPatients.slice(0, 3).map((patient) => (
              <div 
                key={patient.id} 
                className="p-4 border rounded-lg hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center mb-2">
                  <div className="h-10 w-10 rounded-full bg-hospital-light-purple/30 flex items-center justify-center mr-3">
                    <User className="h-5 w-5 text-hospital-purple" />
                  </div>
                  <div>
                    <p className="font-medium">{patient.name}</p>
                    <p className="text-xs text-gray-500">{patient.age} years, {patient.gender}</p>
                  </div>
                </div>
                {patient.medicalHistory && patient.medicalHistory.length > 0 ? (
                  <div className="mt-2">
                    <p className="text-xs font-medium text-gray-500 mb-1">Medical History:</p>
                    <div className="flex flex-wrap gap-1">
                      {patient.medicalHistory.map((condition, idx) => (
                        <span 
                          key={idx} 
                          className="text-xs px-2 py-0.5 rounded bg-hospital-light-purple/10 text-hospital-purple"
                        >
                          {condition}
                        </span>
                      ))}
                    </div>
                  </div>
                ) : null}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DoctorDashboard;
