
import { useState } from 'react';
import { Search, User, FilePlus, Calendar, Filter } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { mockPatients } from '@/lib/mockData';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';

const genderColors = {
  male: 'bg-blue-100 text-blue-700',
  female: 'bg-pink-100 text-pink-700',
  other: 'bg-purple-100 text-purple-700',
};

const DoctorPatients = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [genderFilter, setGenderFilter] = useState<'all' | 'male' | 'female' | 'other'>('all');
  const [isAddingNotes, setIsAddingNotes] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState<string | null>(null);
  const [notes, setNotes] = useState('');

  // Filter patients based on search and gender filter
  const filteredPatients = mockPatients.filter((patient) => {
    const matchesSearch = patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesGender = genderFilter === 'all' || patient.gender === genderFilter;
    return matchesSearch && matchesGender;
  });

  const handleAddNotes = (patientId: string) => {
    setSelectedPatient(patientId);
    setIsAddingNotes(true);
    setNotes('');
  };

  const handleSaveNotes = () => {
    // In a real app, this would save to the database
    toast.success('Notes saved successfully!');
    setIsAddingNotes(false);
    setSelectedPatient(null);
    setNotes('');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Patients</h1>
          <p className="text-muted-foreground">Manage your patients and their records</p>
        </div>
      </div>

      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div className="relative w-full md:w-64">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            type="search"
            placeholder="Search patients..."
            className="pl-8 hospital-input"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="flex gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="gap-2">
                <Filter className="h-4 w-4" />
                Filter
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setGenderFilter('all')}>
                All Genders
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setGenderFilter('male')}>
                Male Only
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setGenderFilter('female')}>
                Female Only
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setGenderFilter('other')}>
                Other Genders
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">All Patients</TabsTrigger>
          <TabsTrigger value="recent">Recent</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Patient List</CardTitle>
              <CardDescription>
                Total patients: {filteredPatients.length}
                {genderFilter !== 'all' && ` (filtered by ${genderFilter})`}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left">
                  <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                    <tr>
                      <th className="px-6 py-3">Name</th>
                      <th className="px-6 py-3">Age</th>
                      <th className="px-6 py-3">Gender</th>
                      <th className="px-6 py-3">Contact</th>
                      <th className="px-6 py-3">Medical History</th>
                      <th className="px-6 py-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {filteredPatients.map((patient) => (
                      <tr key={patient.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 font-medium">
                          <div className="flex items-center">
                            <div className="h-8 w-8 rounded-full bg-hospital-light-purple/30 flex items-center justify-center mr-3">
                              <User className="h-4 w-4 text-hospital-purple" />
                            </div>
                            {patient.name}
                          </div>
                        </td>
                        <td className="px-6 py-4">{patient.age}</td>
                        <td className="px-6 py-4">
                          <Badge className={genderColors[patient.gender]}>
                            {patient.gender}
                          </Badge>
                        </td>
                        <td className="px-6 py-4">
                          <div>
                            <div>{patient.contactNumber}</div>
                            <div className="text-xs text-gray-500">{patient.email}</div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          {patient.medicalHistory && patient.medicalHistory.length > 0 ? (
                            <div className="flex flex-wrap gap-1">
                              {patient.medicalHistory.map((condition, idx) => (
                                <span
                                  key={idx}
                                  className="text-xs px-2 py-0.5 rounded bg-hospital-light-purple/10 text-hospital-purple"
                                >
                                  {condition}
                                </span>
                              ))}
                            </div>
                          ) : (
                            <span className="text-gray-400">No history</span>
                          )}
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline" className="flex items-center gap-1">
                              <FilePlus className="h-4 w-4" />
                              <span 
                                className="hidden md:inline"
                                onClick={() => handleAddNotes(patient.id)}
                              >
                                Add Notes
                              </span>
                            </Button>
                            <Button size="sm" variant="outline" className="flex items-center gap-1">
                              <Calendar className="h-4 w-4" />
                              <span className="hidden md:inline">Schedule</span>
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                
                {filteredPatients.length === 0 && (
                  <div className="text-center py-8">
                    <p className="text-gray-500">No patients found matching your search</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recent" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Recently Visited Patients</CardTitle>
              <CardDescription>Patients who visited in the last 30 days</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {mockPatients.slice(0, 4).map((patient) => (
                  <div
                    key={patient.id}
                    className="border rounded-lg p-4 hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center mb-3">
                      <div className="h-10 w-10 rounded-full bg-hospital-light-purple/30 flex items-center justify-center mr-3">
                        <User className="h-5 w-5 text-hospital-purple" />
                      </div>
                      <div>
                        <p className="font-medium">{patient.name}</p>
                        <p className="text-xs text-gray-500">Last visit: 3 days ago</p>
                      </div>
                    </div>

                    <div className="mb-3">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge className={genderColors[patient.gender]}>
                          {patient.gender}
                        </Badge>
                        <span className="text-sm">{patient.age} years</span>
                      </div>
                      <p className="text-sm">{patient.contactNumber}</p>
                    </div>

                    {patient.medicalHistory && patient.medicalHistory.length > 0 && (
                      <div>
                        <p className="text-xs font-medium text-gray-500 mb-1">Medical History:</p>
                        <div className="flex flex-wrap gap-1">
                          {patient.medicalHistory.map((condition, idx) => (
                            <span
                              key={idx}
                              className="text-xs px-2 py-0.5 rounded bg-hospital-light-purple/10 text-hospital-purple"
                            >
                              {condition}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="mt-4 flex justify-end gap-2">
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="text-hospital-purple"
                        onClick={() => handleAddNotes(patient.id)}
                      >
                        <FilePlus className="h-4 w-4 mr-1" />
                        Notes
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Add Notes Dialog */}
      <Dialog open={isAddingNotes} onOpenChange={setIsAddingNotes}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Patient Notes</DialogTitle>
            <DialogDescription>
              {selectedPatient && (
                <span>
                  Add medical notes for{" "}
                  {mockPatients.find(p => p.id === selectedPatient)?.name}
                </span>
              )}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea 
                id="notes" 
                rows={5} 
                placeholder="Enter your medical notes here..." 
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="hospital-input"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline" 
              onClick={() => setIsAddingNotes(false)}
            >
              Cancel
            </Button>
            <Button onClick={handleSaveNotes} className="hospital-gradient">
              Save Notes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default DoctorPatients;
