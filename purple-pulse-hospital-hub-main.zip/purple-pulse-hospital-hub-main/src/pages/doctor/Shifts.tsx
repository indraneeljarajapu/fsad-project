
import { useState } from 'react';
import { format, startOfWeek, addDays } from 'date-fns';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, Clock, Edit, Save, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { mockDoctors } from '@/lib/mockData';
import { toast } from 'sonner';

interface Shift {
  day: string;
  date: Date;
  startTime: string;
  endTime: string;
  available: boolean;
}

const DoctorShifts = () => {
  const [date, setDate] = useState<Date>(new Date());
  const [isEditing, setIsEditing] = useState(false);

  // Generate weekly shifts based on doctor's availability
  const generateWeeklyShifts = () => {
    const currentDoctor = mockDoctors.find(d => d.id === '1');
    if (!currentDoctor) return [];
    
    const startDate = startOfWeek(date, { weekStartsOn: 1 }); // Start from Monday
    
    return Array.from({ length: 7 }).map((_, index) => {
      const currentDate = addDays(startDate, index);
      const dayName = format(currentDate, 'EEEE');
      const dayAvailability = currentDoctor.availability.find(a => a.day === dayName);
      
      // Check if there are available slots for the day
      const hasAvailableSlots = dayAvailability && dayAvailability.slots.some(s => s.isAvailable);
      
      return {
        day: dayName,
        date: currentDate,
        startTime: hasAvailableSlots ? '09:00 AM' : '',
        endTime: hasAvailableSlots ? '05:00 PM' : '',
        available: hasAvailableSlots,
      };
    });
  };
  
  const [shifts, setShifts] = useState<Shift[]>(generateWeeklyShifts());

  const handlePreviousWeek = () => {
    const newDate = new Date(date);
    newDate.setDate(date.getDate() - 7);
    setDate(newDate);
    setShifts(generateWeeklyShifts());
  };

  const handleNextWeek = () => {
    const newDate = new Date(date);
    newDate.setDate(date.getDate() + 7);
    setDate(newDate);
    setShifts(generateWeeklyShifts());
  };
  
  const handleToggleAvailability = (index: number) => {
    if (!isEditing) return;
    
    const newShifts = [...shifts];
    newShifts[index].available = !newShifts[index].available;
    setShifts(newShifts);
  };
  
  const handleSaveChanges = () => {
    // In a real app, this would save to the database
    setIsEditing(false);
    toast.success('Shifts updated successfully!');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Shift Management</h1>
          <p className="text-muted-foreground">Manage your working hours and availability</p>
        </div>
        
        <div className="flex items-center gap-4">
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className="gap-2"
              >
                <CalendarIcon className="h-4 w-4" />
                {format(date, 'MMMM yyyy')}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="end">
              <Calendar
                mode="single"
                selected={date}
                onSelect={(newDate) => {
                  if (newDate) {
                    setDate(newDate);
                    setShifts(generateWeeklyShifts());
                  }
                }}
                className="p-3 pointer-events-auto"
              />
            </PopoverContent>
          </Popover>
          
          {isEditing ? (
            <Button onClick={handleSaveChanges} className="hospital-gradient">
              <Save className="h-4 w-4 mr-2" />
              Save Changes
            </Button>
          ) : (
            <Button onClick={() => setIsEditing(true)}>
              <Edit className="h-4 w-4 mr-2" />
              Edit Shifts
            </Button>
          )}
        </div>
      </div>
      
      <Tabs defaultValue="week">
        <TabsList>
          <TabsTrigger value="week">Weekly View</TabsTrigger>
          <TabsTrigger value="month">Monthly View</TabsTrigger>
        </TabsList>
        
        <TabsContent value="week" className="mt-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Weekly Schedule</CardTitle>
                <CardDescription>
                  {format(shifts[0]?.date || new Date(), 'MMM d')} - {format(shifts[6]?.date || new Date(), 'MMM d, yyyy')}
                </CardDescription>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="icon" onClick={handlePreviousWeek}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon" onClick={handleNextWeek}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {shifts.map((shift, index) => (
                  <div 
                    key={index} 
                    className={cn(
                      "flex flex-col md:flex-row md:items-center justify-between p-4 rounded-lg border",
                      shift.available ? 'bg-hospital-light-purple/10 border-hospital-light-purple/30' : 'bg-gray-50 border-gray-200'
                    )}
                  >
                    <div className="flex items-center mb-3 md:mb-0">
                      <div 
                        className={cn(
                          "h-12 w-12 rounded-full flex items-center justify-center mr-4",
                          shift.available ? 'bg-hospital-light-purple/30' : 'bg-gray-200'
                        )}
                      >
                        <Clock 
                          className={cn(
                            "h-6 w-6",
                            shift.available ? 'text-hospital-purple' : 'text-gray-500'
                          )} 
                        />
                      </div>
                      <div>
                        <p className="font-medium">{shift.day}</p>
                        <p className="text-sm text-gray-500">{format(shift.date, 'MMM d, yyyy')}</p>
                      </div>
                    </div>
                    
                    <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
                      {shift.available ? (
                        <div className="text-center">
                          <p className="text-sm font-medium">Working Hours</p>
                          <p className="text-sm">{shift.startTime} - {shift.endTime}</p>
                        </div>
                      ) : (
                        <div className="text-center">
                          <p className="text-sm text-gray-500">Not Available</p>
                        </div>
                      )}
                      
                      <div className="flex items-center space-x-2">
                        <Switch 
                          checked={shift.available} 
                          onCheckedChange={() => handleToggleAvailability(index)}
                          disabled={!isEditing}
                        />
                        <Label>Available</Label>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter className="justify-between flex-col sm:flex-row gap-4">
              <div className="text-sm text-gray-500">
                * Toggle availability to mark your working days
              </div>
              {isEditing && (
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setIsEditing(false)}>
                    <X className="h-4 w-4 mr-2" />
                    Cancel
                  </Button>
                  <Button onClick={handleSaveChanges} className="hospital-gradient">
                    <Save className="h-4 w-4 mr-2" />
                    Save Changes
                  </Button>
                </div>
              )}
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="month" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Monthly View</CardTitle>
              <CardDescription>Calendar view of your shifts</CardDescription>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="p-8 text-center">
                <p className="text-gray-500">Monthly view is coming soon.</p>
                <p className="text-gray-500">Please use the Weekly View for now.</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default DoctorShifts;
