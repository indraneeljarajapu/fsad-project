
import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { User, Phone, Mail, GraduationCap, Building, Clock } from 'lucide-react';
import { mockDoctors } from '@/lib/mockData';

const DoctorProfile = () => {
  const { user } = useAuth();
  const doctorData = mockDoctors.find((d) => d.id === '1');
  
  const [personalInfo, setPersonalInfo] = useState({
    name: doctorData?.name || user?.name || '',
    email: user?.email || '',
    phone: '(123) 456-7890',
    specialty: doctorData?.specialty || '',
    experience: doctorData?.experience?.toString() || '',
    qualification: 'MD, Cardiology',
    hospital: 'MediCare General Hospital',
    address: '456 Medical Drive, Healthcare City, USA',
    bio: 'Experienced cardiologist with a focus on preventive care and heart health management. Specializes in cardiovascular disease diagnosis, treatment, and prevention.',
  });
  
  const [isEditing, setIsEditing] = useState(false);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setPersonalInfo((prev) => ({ ...prev, [name]: value }));
  };
  
  const handleSaveChanges = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would save to the database
    setIsEditing(false);
    toast.success('Profile updated successfully!');
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Doctor Profile</h1>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Profile Summary Card */}
        <Card className="hospital-card md:row-span-2">
          <CardHeader className="text-center pb-2">
            <div className="flex justify-center mb-4">
              <div className="h-24 w-24 rounded-full bg-hospital-light-purple flex items-center justify-center">
                <User className="h-12 w-12 text-hospital-purple" />
              </div>
            </div>
            <CardTitle>{personalInfo.name}</CardTitle>
            <div className="flex justify-center mt-1">
              <Badge variant="outline" className="bg-hospital-light-purple/20 text-hospital-purple border-hospital-light-purple">
                {personalInfo.specialty}
              </Badge>
            </div>
            <CardDescription className="mt-2">{personalInfo.email}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-3 text-sm">
              <Phone className="h-4 w-4 text-gray-500" />
              <span>{personalInfo.phone}</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <Mail className="h-4 w-4 text-gray-500" />
              <span>{personalInfo.email}</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <GraduationCap className="h-4 w-4 text-gray-500" />
              <span>{personalInfo.qualification}</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <Building className="h-4 w-4 text-gray-500" />
              <span>{personalInfo.hospital}</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <Clock className="h-4 w-4 text-gray-500" />
              <span>{personalInfo.experience} years experience</span>
            </div>
          </CardContent>
          <CardFooter className="border-t pt-4">
            <Button 
              onClick={() => setIsEditing(true)}
              className="w-full"
              variant="outline"
            >
              Edit Profile
            </Button>
          </CardFooter>
        </Card>
        
        {/* Main Content Area */}
        <div className="md:col-span-2">
          <Tabs defaultValue="professional">
            <TabsList className="mb-6 grid grid-cols-2 md:flex">
              <TabsTrigger value="professional">Professional Info</TabsTrigger>
              <TabsTrigger value="experience">Experience</TabsTrigger>
            </TabsList>
            
            <TabsContent value="professional">
              <Card className="hospital-card">
                <form onSubmit={handleSaveChanges}>
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <div>
                        <CardTitle>Professional Information</CardTitle>
                        <CardDescription>Your professional details and qualifications</CardDescription>
                      </div>
                      {isEditing ? (
                        <div className="space-x-2">
                          <Button 
                            type="button" 
                            variant="outline" 
                            onClick={() => setIsEditing(false)}
                          >
                            Cancel
                          </Button>
                          <Button type="submit" className="hospital-gradient">
                            Save Changes
                          </Button>
                        </div>
                      ) : (
                        <Button 
                          type="button" 
                          onClick={() => setIsEditing(true)}
                        >
                          Edit
                        </Button>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Full Name</Label>
                        <Input 
                          id="name" 
                          name="name"
                          value={personalInfo.name} 
                          onChange={handleInputChange}
                          readOnly={!isEditing}
                          className={!isEditing ? 'bg-gray-50' : 'hospital-input'}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input 
                          id="email" 
                          name="email"
                          type="email" 
                          value={personalInfo.email} 
                          onChange={handleInputChange}
                          readOnly={!isEditing}
                          className={!isEditing ? 'bg-gray-50' : 'hospital-input'}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone Number</Label>
                        <Input 
                          id="phone" 
                          name="phone"
                          value={personalInfo.phone} 
                          onChange={handleInputChange}
                          readOnly={!isEditing}
                          className={!isEditing ? 'bg-gray-50' : 'hospital-input'}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="specialty">Specialty</Label>
                        <Input 
                          id="specialty" 
                          name="specialty"
                          value={personalInfo.specialty} 
                          onChange={handleInputChange}
                          readOnly={!isEditing}
                          className={!isEditing ? 'bg-gray-50' : 'hospital-input'}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="experience">Years of Experience</Label>
                        <Input 
                          id="experience" 
                          name="experience"
                          type="number"
                          value={personalInfo.experience} 
                          onChange={handleInputChange}
                          readOnly={!isEditing}
                          className={!isEditing ? 'bg-gray-50' : 'hospital-input'}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="qualification">Qualifications</Label>
                        <Input 
                          id="qualification" 
                          name="qualification"
                          value={personalInfo.qualification} 
                          onChange={handleInputChange}
                          readOnly={!isEditing}
                          className={!isEditing ? 'bg-gray-50' : 'hospital-input'}
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="bio">Professional Bio</Label>
                      <Textarea 
                        id="bio" 
                        name="bio"
                        rows={4}
                        value={personalInfo.bio} 
                        onChange={handleInputChange}
                        readOnly={!isEditing}
                        className={!isEditing ? 'bg-gray-50' : 'hospital-input'}
                      />
                    </div>
                  </CardContent>
                </form>
              </Card>
            </TabsContent>
            
            <TabsContent value="experience">
              <Card className="hospital-card">
                <CardHeader>
                  <CardTitle>Experience & Education</CardTitle>
                  <CardDescription>Your professional background and qualifications</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <h3 className="font-medium mb-4">Work Experience</h3>
                    <div className="space-y-4">
                      <div className="border-l-2 border-hospital-light-purple pl-4 pb-4">
                        <div className="flex justify-between">
                          <h4 className="font-medium">Senior Cardiologist</h4>
                          <span className="text-sm text-gray-500">2020 - Present</span>
                        </div>
                        <p className="text-sm text-gray-600">MediCare General Hospital</p>
                        <p className="text-sm mt-2">
                          Leading the cardiology department and specializing in complex cardiac cases.
                        </p>
                      </div>
                      <div className="border-l-2 border-gray-200 pl-4 pb-4">
                        <div className="flex justify-between">
                          <h4 className="font-medium">Cardiologist</h4>
                          <span className="text-sm text-gray-500">2015 - 2020</span>
                        </div>
                        <p className="text-sm text-gray-600">Central City Hospital</p>
                        <p className="text-sm mt-2">
                          Provided comprehensive cardiac care and participated in cardiac research studies.
                        </p>
                      </div>
                      <div className="border-l-2 border-gray-200 pl-4">
                        <div className="flex justify-between">
                          <h4 className="font-medium">Resident Physician</h4>
                          <span className="text-sm text-gray-500">2012 - 2015</span>
                        </div>
                        <p className="text-sm text-gray-600">University Medical Center</p>
                        <p className="text-sm mt-2">
                          Completed residency in internal medicine with a focus on cardiology.
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="border-t pt-6">
                    <h3 className="font-medium mb-4">Education</h3>
                    <div className="space-y-4">
                      <div className="border-l-2 border-hospital-light-purple pl-4 pb-4">
                        <div className="flex justify-between">
                          <h4 className="font-medium">Fellowship in Cardiology</h4>
                          <span className="text-sm text-gray-500">2015</span>
                        </div>
                        <p className="text-sm text-gray-600">National Heart Institute</p>
                      </div>
                      <div className="border-l-2 border-gray-200 pl-4">
                        <div className="flex justify-between">
                          <h4 className="font-medium">Doctor of Medicine (MD)</h4>
                          <span className="text-sm text-gray-500">2012</span>
                        </div>
                        <p className="text-sm text-gray-600">University Medical School</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="border-t pt-6">
                    <h3 className="font-medium mb-4">Certifications</h3>
                    <div className="space-y-2">
                      <div className="p-3 bg-hospital-light-purple/5 border border-hospital-light-purple/20 rounded-lg">
                        <p className="font-medium">Board Certified in Cardiology</p>
                        <div className="flex justify-between text-sm mt-1">
                          <span>National Board of Cardiology</span>
                          <span className="text-gray-500">Exp: 2028</span>
                        </div>
                      </div>
                      <div className="p-3 bg-gray-50 border border-gray-200 rounded-lg">
                        <p className="font-medium">Advanced Cardiac Life Support (ACLS)</p>
                        <div className="flex justify-between text-sm mt-1">
                          <span>American Heart Association</span>
                          <span className="text-gray-500">Renewed yearly</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="ml-auto">Add New Entry</Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default DoctorProfile;
