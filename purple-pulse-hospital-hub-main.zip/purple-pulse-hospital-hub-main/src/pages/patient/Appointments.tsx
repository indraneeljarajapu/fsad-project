
import { useState } from 'react';
import { toast } from 'sonner';
import { Calendar as CalendarIcon, Check, CreditCard, User } from 'lucide-react';
import { format } from 'date-fns';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { mockDoctors, mockAppointments } from '@/lib/mockData';
import { cn } from '@/lib/utils';

const PatientAppointments = () => {
  const [selectedDoctor, setSelectedDoctor] = useState<string | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [step, setStep] = useState<number>(1);
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);
  
  // Patient's existing appointments
  const patientAppointments = mockAppointments.filter(
    (appointment) => appointment.patientId === '1'
  );

  const upcomingAppointments = patientAppointments.filter(
    (appointment) => appointment.status === 'scheduled'
  );
  
  const pastAppointments = patientAppointments.filter(
    (appointment) => appointment.status !== 'scheduled'
  );

  // Function to check if a doctor has available slots on a specific day
  const getDoctorAvailability = (doctorId: string, date: Date) => {
    const doctor = mockDoctors.find(d => d.id === doctorId);
    if (!doctor) return [];
    
    const dayName = format(date, 'EEEE');
    const availabilityForDay = doctor.availability.find(a => a.day === dayName);
    
    if (!availabilityForDay) return [];
    return availabilityForDay.slots.filter(slot => slot.isAvailable);
  };

  // Function to handle appointment booking
  const handleBookAppointment = () => {
    if (!selectedDoctor || !selectedDate || !selectedTime) {
      toast.error("Please select doctor, date and time");
      return;
    }
    
    setIsPaymentDialogOpen(true);
  };

  // Function to handle payment submission
  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const doctor = mockDoctors.find(d => d.id === selectedDoctor);
    
    // In a real app, this would process payment and save the appointment
    toast.success("Appointment booked successfully!");
    setIsPaymentDialogOpen(false);
    
    // Reset selection
    setSelectedDoctor(null);
    setSelectedDate(undefined);
    setSelectedTime(null);
    setStep(1);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Appointments</h1>
      </div>
      
      <Tabs defaultValue="new">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="new">Book New Appointment</TabsTrigger>
          <TabsTrigger value="existing">My Appointments</TabsTrigger>
        </TabsList>
        
        <TabsContent value="new">
          <div className="grid gap-6 md:grid-cols-12">
            {/* Doctor Selection (Step 1) */}
            <Card className={cn("hospital-card md:col-span-12 lg:col-span-4", 
              step !== 1 && "opacity-75 border-dashed"
            )}>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>1. Select Doctor</CardTitle>
                  <CardDescription>Choose your preferred doctor</CardDescription>
                </div>
                {selectedDoctor && step > 1 && (
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setStep(1)}
                  >
                    Edit
                  </Button>
                )}
              </CardHeader>
              <CardContent className={step !== 1 ? "hidden md:block" : ""}>
                <div className="space-y-4">
                  {mockDoctors.map((doctor) => (
                    <div 
                      key={doctor.id} 
                      className={cn(
                        "p-4 rounded-lg cursor-pointer border transition-all",
                        selectedDoctor === doctor.id 
                          ? "border-hospital-purple bg-hospital-light-purple/10" 
                          : "border-gray-200 hover:border-hospital-light-purple"
                      )}
                      onClick={() => {
                        setSelectedDoctor(doctor.id);
                        if (step === 1) setStep(2);
                      }}
                    >
                      <div className="flex items-center gap-3">
                        <div className="h-12 w-12 rounded-full bg-hospital-light-purple/30 flex items-center justify-center">
                          <User className="h-6 w-6 text-hospital-purple" />
                        </div>
                        <div>
                          <p className="font-medium">{doctor.name}</p>
                          <p className="text-sm text-gray-500">{doctor.specialty}</p>
                          <p className="text-xs text-gray-400">{doctor.experience} years experience</p>
                        </div>
                        {selectedDoctor === doctor.id && (
                          <Check className="ml-auto h-5 w-5 text-hospital-purple" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Date Selection (Step 2) */}
            <Card className={cn("hospital-card md:col-span-6 lg:col-span-4", 
              (step !== 2 || !selectedDoctor) && "opacity-75 border-dashed"
            )}>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>2. Select Date & Time</CardTitle>
                  <CardDescription>Choose your preferred schedule</CardDescription>
                </div>
                {selectedDate && selectedTime && step > 2 && (
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setStep(2)}
                  >
                    Edit
                  </Button>
                )}
              </CardHeader>
              <CardContent className={step !== 2 ? "hidden md:block" : ""}>
                <div className="flex flex-col space-y-4">
                  <div className="flex justify-center">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !selectedDate && "text-muted-foreground"
                          )}
                          disabled={!selectedDoctor || step < 2}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {selectedDate ? format(selectedDate, 'PPP') : <span>Select date</span>}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="center">
                        <Calendar
                          mode="single"
                          selected={selectedDate}
                          onSelect={setSelectedDate}
                          disabled={(date) => {
                            // Disable dates in the past or dates with no availability
                            const isPastDate = date < new Date();
                            const isAvailable = selectedDoctor 
                              ? getDoctorAvailability(selectedDoctor, date).length > 0
                              : false;
                            return isPastDate || !isAvailable;
                          }}
                          className="p-3 pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                  
                  {/* Time slot selection */}
                  {selectedDoctor && selectedDate && (
                    <div className="space-y-2">
                      <Label>Available Time Slots</Label>
                      <div className="grid grid-cols-3 gap-2">
                        {getDoctorAvailability(selectedDoctor, selectedDate).length > 0 ? (
                          getDoctorAvailability(selectedDoctor, selectedDate).map((slot) => (
                            <Button
                              key={slot.time}
                              variant={selectedTime === slot.time ? "default" : "outline"}
                              className={selectedTime === slot.time ? "hospital-gradient" : ""}
                              onClick={() => {
                                setSelectedTime(slot.time);
                                if (step === 2) setStep(3);
                              }}
                            >
                              {slot.time}
                            </Button>
                          ))
                        ) : (
                          <p className="col-span-3 text-center text-sm text-gray-500">
                            No available slots on this day
                          </p>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Confirmation and Payment (Step 3) */}
            <Card className={cn("hospital-card md:col-span-6 lg:col-span-4", 
              (step !== 3 || !selectedDoctor || !selectedDate || !selectedTime) && "opacity-75 border-dashed"
            )}>
              <CardHeader>
                <CardTitle>3. Confirm & Pay</CardTitle>
                <CardDescription>Review your appointment details</CardDescription>
              </CardHeader>
              <CardContent>
                {selectedDoctor && selectedDate && selectedTime && (
                  <div className="space-y-4">
                    <div className="rounded-lg bg-hospital-light-purple/10 p-4">
                      <h4 className="font-medium mb-2">Appointment Details</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-500">Doctor:</span>
                          <span className="font-medium">
                            {mockDoctors.find(d => d.id === selectedDoctor)?.name}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">Specialty:</span>
                          <span>
                            {mockDoctors.find(d => d.id === selectedDoctor)?.specialty}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">Date:</span>
                          <span>{selectedDate && format(selectedDate, 'PPPP')}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">Time:</span>
                          <span>{selectedTime}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">Appointment Fee:</span>
                          <span className="font-medium">$150.00</span>
                        </div>
                      </div>
                    </div>
                    <Button 
                      onClick={handleBookAppointment} 
                      className="w-full hospital-gradient"
                      disabled={!selectedDoctor || !selectedDate || !selectedTime || step < 3}
                    >
                      <CreditCard className="mr-2 h-4 w-4" />
                      Proceed to Payment
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="existing">
          <Tabs defaultValue="upcoming">
            <TabsList className="mb-6">
              <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
              <TabsTrigger value="past">Past</TabsTrigger>
            </TabsList>
            
            <TabsContent value="upcoming">
              <div className="space-y-4">
                {upcomingAppointments.length > 0 ? (
                  upcomingAppointments.map((appointment) => {
                    const doctor = mockDoctors.find(d => d.id === appointment.doctorId);
                    return (
                      <Card key={appointment.id} className="hospital-card">
                        <CardContent className="p-6">
                          <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                            <div className="flex items-center mb-4 md:mb-0">
                              <div className="h-12 w-12 rounded-full bg-hospital-light-purple/30 flex items-center justify-center mr-4">
                                <User className="h-6 w-6 text-hospital-purple" />
                              </div>
                              <div>
                                <p className="font-medium">{doctor?.name}</p>
                                <p className="text-sm text-gray-500">{doctor?.specialty}</p>
                                <div className="flex items-center mt-1">
                                  <CalendarIcon className="h-3 w-3 text-gray-400 mr-1" />
                                  <span className="text-xs text-gray-500">
                                    {appointment.date} at {appointment.time}
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className="flex flex-col md:flex-row gap-2">
                              <Button variant="outline" size="sm">
                                Reschedule
                              </Button>
                              <Button variant="outline" size="sm" className="text-red-500 border-red-200">
                                Cancel
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })
                ) : (
                  <div className="text-center py-12">
                    <p className="text-muted-foreground mb-4">No upcoming appointments</p>
                    <Button
                      onClick={() => document.querySelector('button[value="new"]')?.click()}
                      className="hospital-gradient"
                    >
                      Book an Appointment
                    </Button>
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="past">
              <div className="space-y-4">
                {pastAppointments.length > 0 ? (
                  pastAppointments.map((appointment) => {
                    const doctor = mockDoctors.find(d => d.id === appointment.doctorId);
                    return (
                      <Card key={appointment.id} className="hospital-card opacity-75">
                        <CardContent className="p-6">
                          <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                            <div className="flex items-center mb-4 md:mb-0">
                              <div className="h-12 w-12 rounded-full bg-gray-200 flex items-center justify-center mr-4">
                                <User className="h-6 w-6 text-gray-500" />
                              </div>
                              <div>
                                <p className="font-medium">{doctor?.name}</p>
                                <p className="text-sm text-gray-500">{doctor?.specialty}</p>
                                <div className="flex items-center mt-1">
                                  <CalendarIcon className="h-3 w-3 text-gray-400 mr-1" />
                                  <span className="text-xs text-gray-500">
                                    {appointment.date} at {appointment.time}
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div>
                              <span className="px-2 py-1 text-xs rounded-full bg-gray-100 text-gray-700 capitalize">
                                {appointment.status}
                              </span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })
                ) : (
                  <div className="text-center py-12">
                    <p className="text-muted-foreground">No past appointments</p>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </TabsContent>
      </Tabs>
      
      {/* Payment Dialog */}
      <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Complete Payment</DialogTitle>
            <DialogDescription>
              Enter your payment details to confirm your appointment
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handlePaymentSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="cardName">Cardholder Name</Label>
              <Input id="cardName" placeholder="John Doe" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="cardNumber">Card Number</Label>
              <Input id="cardNumber" placeholder="4242 4242 4242 4242" required />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="expiryDate">Expiry Date</Label>
                <Input id="expiryDate" placeholder="MM/YY" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cvv">CVV</Label>
                <Input id="cvv" placeholder="123" required />
              </div>
            </div>
            
            <div className="border-t pt-4 mt-4">
              <div className="flex justify-between mb-2">
                <span>Appointment Fee</span>
                <span>$150.00</span>
              </div>
              <div className="flex justify-between font-semibold">
                <span>Total</span>
                <span>$150.00</span>
              </div>
            </div>
            
            <DialogFooter>
              <Button
                variant="outline" 
                onClick={() => setIsPaymentDialogOpen(false)}
                className="mt-2 sm:mt-0"
              >
                Cancel
              </Button>
              <Button type="submit" className="hospital-gradient">
                Pay $150.00
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PatientAppointments;
