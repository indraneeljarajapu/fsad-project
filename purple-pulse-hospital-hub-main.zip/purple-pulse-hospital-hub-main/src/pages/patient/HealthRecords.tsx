
import { useState } from 'react';
import { FileText, Search, ChevronDown, Download } from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger 
} from '@/components/ui/collapsible';
import { mockHealthRecords, mockDoctors } from '@/lib/mockData';

const PatientHealthRecords = () => {
  const [searchTerm, setSearchTerm] = useState('');
  
  // Filter health records for current patient
  const patientHealthRecords = mockHealthRecords.filter(
    (record) => record.patientId === '1'
  );
  
  // Filter records based on search term
  const filteredRecords = patientHealthRecords.filter(record => 
    record.diagnosis.toLowerCase().includes(searchTerm.toLowerCase()) || 
    record.prescription.toLowerCase().includes(searchTerm.toLowerCase()) ||
    record.notes.toLowerCase().includes(searchTerm.toLowerCase()) ||
    mockDoctors.find(d => d.id === record.doctorId)?.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
        <h1 className="text-2xl font-bold">Health Records</h1>
        
        <div className="relative w-full md:w-64">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input 
            type="search"
            placeholder="Search records..." 
            className="pl-8 hospital-input"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">All Records</TabsTrigger>
          <TabsTrigger value="diagnoses">Diagnoses</TabsTrigger>
          <TabsTrigger value="prescriptions">Prescriptions</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-6">
          {filteredRecords.length > 0 ? (
            <div className="space-y-4">
              {filteredRecords.map((record) => {
                const doctor = mockDoctors.find(d => d.id === record.doctorId);
                return (
                  <Collapsible key={record.id} className="hospital-card">
                    <div className="flex justify-between items-center p-4">
                      <div className="flex items-start space-x-4">
                        <div className="bg-hospital-light-purple/20 p-3 rounded-lg">
                          <FileText className="h-6 w-6 text-hospital-purple" />
                        </div>
                        <div>
                          <h3 className="font-medium">{record.diagnosis}</h3>
                          <p className="text-sm text-gray-500">
                            Dr. {doctor?.name} · {record.date}
                          </p>
                        </div>
                      </div>
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <ChevronDown className="h-4 w-4" />
                          <span className="sr-only">Toggle</span>
                        </Button>
                      </CollapsibleTrigger>
                    </div>
                    <CollapsibleContent>
                      <div className="px-4 pb-4 pt-1 space-y-4">
                        <div className="space-y-2">
                          <h4 className="text-sm font-medium">Prescription</h4>
                          <p className="text-sm border-l-2 border-hospital-light-purple pl-3 py-1">
                            {record.prescription}
                          </p>
                        </div>
                        <div className="space-y-2">
                          <h4 className="text-sm font-medium">Doctor's Notes</h4>
                          <p className="text-sm border-l-2 border-gray-200 pl-3 py-1 text-gray-700">
                            {record.notes}
                          </p>
                        </div>
                        <div className="flex justify-end">
                          <Button variant="outline" size="sm" className="text-hospital-purple">
                            <Download className="h-4 w-4 mr-1" />
                            Download PDF
                          </Button>
                        </div>
                      </div>
                    </CollapsibleContent>
                  </Collapsible>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No health records found</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="diagnoses" className="mt-6">
          <Card className="hospital-card">
            <CardHeader>
              <CardTitle>Diagnosis History</CardTitle>
              <CardDescription>Overview of your past diagnoses</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredRecords.map((record) => (
                  <div key={record.id} className="flex justify-between items-center p-3 border-b last:border-0">
                    <div>
                      <p className="font-medium">{record.diagnosis}</p>
                      <p className="text-sm text-gray-500">{record.date}</p>
                    </div>
                    <Button variant="outline" size="sm">
                      View Details
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="prescriptions" className="mt-6">
          <Card className="hospital-card">
            <CardHeader>
              <CardTitle>Prescription History</CardTitle>
              <CardDescription>Medications prescribed to you</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredRecords.map((record) => (
                  <div key={record.id} className="flex justify-between items-center p-3 border-b last:border-0">
                    <div>
                      <p className="font-medium">{record.prescription}</p>
                      <p className="text-sm text-gray-500">For: {record.diagnosis}</p>
                      <p className="text-xs text-gray-400">{record.date}</p>
                    </div>
                    <Button variant="outline" size="sm">
                      Refill Request
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default PatientHealthRecords;
