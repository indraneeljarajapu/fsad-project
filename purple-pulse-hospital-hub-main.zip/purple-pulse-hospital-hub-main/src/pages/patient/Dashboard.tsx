
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Calendar, Clock, FileText, Heart, User, X } from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { mockAppointments, mockDoctors, mockHealthRecords } from '@/lib/mockData';

const PatientDashboard = () => {
  const { user } = useAuth();
  const [upcomingTab, setUpcomingTab] = useState('upcoming');
  
  // Filter appointments for current patient
  const patientAppointments = mockAppointments.filter(
    (appointment) => appointment.patientId === '1'
  );

  const upcomingAppointments = patientAppointments.filter(
    (appointment) => appointment.status === 'scheduled'
  );
  
  const completedAppointments = patientAppointments.filter(
    (appointment) => appointment.status === 'completed'
  );

  // Filter health records for current patient
  const patientHealthRecords = mockHealthRecords.filter(
    (record) => record.patientId === '1'
  );

  return (
    <div className="space-y-6">
      {/* Welcome & Quick Stats */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="hospital-card bg-gradient-to-br from-hospital-purple to-hospital-light-purple text-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-white text-xl">Welcome Back</CardTitle>
            <CardDescription className="text-white text-opacity-90">
              {user?.name}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-lg font-semibold">How are you feeling today?</p>
          </CardContent>
          <CardFooter>
            <Button asChild variant="secondary" className="w-full text-hospital-purple">
              <Link to="/patient-appointments">Book Appointment</Link>
            </Button>
          </CardFooter>
        </Card>

        {/* Quick Stats */}
        <Card className="hospital-card">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Upcoming Appointments</CardTitle>
            <Calendar className="h-4 w-4 text-hospital-purple" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{upcomingAppointments.length}</div>
            <p className="text-xs text-muted-foreground">
              Next on {upcomingAppointments[0]?.date || 'N/A'}
            </p>
          </CardContent>
          <CardFooter className="p-2">
            <Link 
              to="/patient-appointments" 
              className="text-xs text-hospital-purple hover:underline w-full text-right"
            >
              View all
            </Link>
          </CardFooter>
        </Card>

        <Card className="hospital-card">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Health Records</CardTitle>
            <FileText className="h-4 w-4 text-hospital-purple" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{patientHealthRecords.length}</div>
            <p className="text-xs text-muted-foreground">
              Last updated on {patientHealthRecords[0]?.date || 'N/A'}
            </p>
          </CardContent>
          <CardFooter className="p-2">
            <Link 
              to="/patient-records" 
              className="text-xs text-hospital-purple hover:underline w-full text-right"
            >
              View records
            </Link>
          </CardFooter>
        </Card>

        <Card className="hospital-card">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Health Status</CardTitle>
            <Heart className="h-4 w-4 text-hospital-purple" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Good</span>
              <span className="text-xs text-muted-foreground">80%</span>
            </div>
            <Progress value={80} className="mt-2 h-2" />
            <p className="mt-2 text-xs text-muted-foreground">
              Based on your latest check-up
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Appointments Section */}
      <div className="grid gap-6 md:grid-cols-3">
        <div className="md:col-span-2">
          <Card className="hospital-card">
            <CardHeader>
              <CardTitle>Your Appointments</CardTitle>
              <Tabs 
                defaultValue="upcoming" 
                value={upcomingTab} 
                onValueChange={setUpcomingTab}
                className="w-full"
              >
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
                  <TabsTrigger value="past">Past</TabsTrigger>
                </TabsList>
                
                <TabsContent value="upcoming" className="mt-4">
                  {upcomingAppointments.length > 0 ? (
                    <div className="space-y-4">
                      {upcomingAppointments.map((appointment) => {
                        const doctor = mockDoctors.find(d => d.id === appointment.doctorId);
                        return (
                          <div key={appointment.id} className="flex items-center justify-between p-4 bg-white rounded-lg border border-hospital-light-purple/20">
                            <div className="flex items-center">
                              <div className="h-10 w-10 rounded-full bg-hospital-light-purple/30 flex items-center justify-center mr-3">
                                <User className="h-5 w-5 text-hospital-purple" />
                              </div>
                              <div>
                                <p className="font-medium">{doctor?.name}</p>
                                <p className="text-sm text-gray-500">{doctor?.specialty}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="flex items-center">
                                <Calendar className="h-4 w-4 text-gray-400 mr-1" />
                                <span className="text-sm">{appointment.date}</span>
                              </div>
                              <div className="flex items-center mt-1">
                                <Clock className="h-4 w-4 text-gray-400 mr-1" />
                                <span className="text-sm">{appointment.time}</span>
                              </div>
                            </div>
                            <div>
                              <Button variant="outline" size="sm" className="mr-2">
                                Reschedule
                              </Button>
                              <Button variant="outline" size="sm" className="text-red-500 border-red-200">
                                <X className="h-4 w-4 mr-1" />
                                Cancel
                              </Button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-center py-6">
                      <p className="text-muted-foreground">No upcoming appointments</p>
                      <Button asChild className="mt-4 hospital-gradient">
                        <Link to="/patient-appointments">Book an Appointment</Link>
                      </Button>
                    </div>
                  )}
                </TabsContent>
                
                <TabsContent value="past" className="mt-4">
                  {completedAppointments.length > 0 ? (
                    <div className="space-y-4">
                      {completedAppointments.map((appointment) => {
                        const doctor = mockDoctors.find(d => d.id === appointment.doctorId);
                        return (
                          <div key={appointment.id} className="flex items-center justify-between p-4 bg-white rounded-lg border border-gray-200">
                            <div className="flex items-center">
                              <div className="h-10 w-10 rounded-full bg-gray-100 flex items-center justify-center mr-3">
                                <User className="h-5 w-5 text-gray-500" />
                              </div>
                              <div>
                                <p className="font-medium">{doctor?.name}</p>
                                <p className="text-sm text-gray-500">{doctor?.specialty}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="flex items-center">
                                <Calendar className="h-4 w-4 text-gray-400 mr-1" />
                                <span className="text-sm">{appointment.date}</span>
                              </div>
                              <div className="flex items-center mt-1">
                                <Clock className="h-4 w-4 text-gray-400 mr-1" />
                                <span className="text-sm">{appointment.time}</span>
                              </div>
                            </div>
                            <Button variant="outline" size="sm">
                              View Details
                            </Button>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-center py-6">
                      <p className="text-muted-foreground">No past appointments</p>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </CardHeader>
          </Card>
        </div>
        
        {/* Health Records Snippet */}
        <Card className="hospital-card">
          <CardHeader>
            <CardTitle>Recent Health Records</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {patientHealthRecords.slice(0, 2).map((record) => {
              const doctor = mockDoctors.find(d => d.id === record.doctorId);
              return (
                <div key={record.id} className="p-3 border border-hospital-light-purple/20 rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <p className="font-medium">{record.diagnosis}</p>
                      <p className="text-sm text-gray-500">{doctor?.name}</p>
                    </div>
                    <span className="text-xs text-gray-500">{record.date}</span>
                  </div>
                  <p className="text-sm mb-2">
                    <span className="font-medium">Prescription:</span> {record.prescription}
                  </p>
                  <p className="text-xs text-gray-500">{record.notes}</p>
                </div>
              );
            })}
          </CardContent>
          <CardFooter>
            <Button asChild variant="outline" className="w-full">
              <Link to="/patient-records">View All Records</Link>
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default PatientDashboard;
