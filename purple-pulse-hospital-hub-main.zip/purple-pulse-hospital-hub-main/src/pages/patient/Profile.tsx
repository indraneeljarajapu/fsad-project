
import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { User, Phone, Mail, Home, Lock, Bell, Shield } from 'lucide-react';
import { mockPatients } from '@/lib/mockData';

const PatientProfile = () => {
  const { user } = useAuth();
  const patientData = mockPatients.find((p) => p.id === '1');
  
  const [personalInfo, setPersonalInfo] = useState({
    name: patientData?.name || user?.name || '',
    email: patientData?.email || user?.email || '',
    phone: patientData?.contactNumber || '',
    address: '123 Main St, Anytown, USA',
    bloodGroup: 'O+',
    height: '5\'10"',
    weight: '170 lbs',
  });
  
  const [isEditing, setIsEditing] = useState(false);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setPersonalInfo((prev) => ({ ...prev, [name]: value }));
  };
  
  const handleSaveChanges = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would save to the database
    setIsEditing(false);
    toast.success('Profile updated successfully!');
  };

  const medicalHistory = patientData?.medicalHistory || [];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Profile</h1>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Profile Summary Card */}
        <Card className="hospital-card md:row-span-2">
          <CardHeader className="text-center pb-2">
            <div className="flex justify-center mb-4">
              <div className="h-24 w-24 rounded-full bg-hospital-light-purple flex items-center justify-center">
                <User className="h-12 w-12 text-hospital-purple" />
              </div>
            </div>
            <CardTitle>{personalInfo.name}</CardTitle>
            <div className="flex justify-center mt-1">
              <Badge variant="outline" className="bg-hospital-light-purple/20 text-hospital-purple border-hospital-light-purple">
                Patient
              </Badge>
            </div>
            <CardDescription className="mt-2">{personalInfo.email}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-3 text-sm">
              <Phone className="h-4 w-4 text-gray-500" />
              <span>{personalInfo.phone}</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <Mail className="h-4 w-4 text-gray-500" />
              <span>{personalInfo.email}</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <Home className="h-4 w-4 text-gray-500" />
              <span>{personalInfo.address}</span>
            </div>
          </CardContent>
          <CardFooter className="border-t pt-4">
            <Button 
              onClick={() => setIsEditing(true)}
              className="w-full"
              variant="outline"
            >
              Edit Profile
            </Button>
          </CardFooter>
        </Card>
        
        {/* Main Content Area */}
        <div className="md:col-span-2">
          <Tabs defaultValue="personal">
            <TabsList className="mb-6 grid grid-cols-3 md:flex">
              <TabsTrigger value="personal">Personal Info</TabsTrigger>
              <TabsTrigger value="medical">Medical History</TabsTrigger>
              <TabsTrigger value="security">Security</TabsTrigger>
            </TabsList>
            
            <TabsContent value="personal">
              <Card className="hospital-card">
                <form onSubmit={handleSaveChanges}>
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <div>
                        <CardTitle>Personal Information</CardTitle>
                        <CardDescription>Manage your personal details</CardDescription>
                      </div>
                      {isEditing ? (
                        <div className="space-x-2">
                          <Button 
                            type="button" 
                            variant="outline" 
                            onClick={() => setIsEditing(false)}
                          >
                            Cancel
                          </Button>
                          <Button type="submit" className="hospital-gradient">
                            Save Changes
                          </Button>
                        </div>
                      ) : (
                        <Button 
                          type="button" 
                          onClick={() => setIsEditing(true)}
                        >
                          Edit
                        </Button>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Full Name</Label>
                        <Input 
                          id="name" 
                          name="name"
                          value={personalInfo.name} 
                          onChange={handleInputChange}
                          readOnly={!isEditing}
                          className={!isEditing ? 'bg-gray-50' : 'hospital-input'}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input 
                          id="email" 
                          name="email"
                          type="email" 
                          value={personalInfo.email} 
                          onChange={handleInputChange}
                          readOnly={!isEditing}
                          className={!isEditing ? 'bg-gray-50' : 'hospital-input'}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone Number</Label>
                        <Input 
                          id="phone" 
                          name="phone"
                          value={personalInfo.phone} 
                          onChange={handleInputChange}
                          readOnly={!isEditing}
                          className={!isEditing ? 'bg-gray-50' : 'hospital-input'}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="address">Address</Label>
                        <Input 
                          id="address" 
                          name="address"
                          value={personalInfo.address} 
                          onChange={handleInputChange}
                          readOnly={!isEditing}
                          className={!isEditing ? 'bg-gray-50' : 'hospital-input'}
                        />
                      </div>
                    </div>
                    
                    <div className="border-t pt-4">
                      <h3 className="font-medium mb-4">Physical Information</h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="bloodGroup">Blood Group</Label>
                          <Input 
                            id="bloodGroup" 
                            name="bloodGroup"
                            value={personalInfo.bloodGroup} 
                            onChange={handleInputChange}
                            readOnly={!isEditing}
                            className={!isEditing ? 'bg-gray-50' : 'hospital-input'}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="height">Height</Label>
                          <Input 
                            id="height" 
                            name="height"
                            value={personalInfo.height} 
                            onChange={handleInputChange}
                            readOnly={!isEditing}
                            className={!isEditing ? 'bg-gray-50' : 'hospital-input'}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="weight">Weight</Label>
                          <Input 
                            id="weight" 
                            name="weight"
                            value={personalInfo.weight} 
                            onChange={handleInputChange}
                            readOnly={!isEditing}
                            className={!isEditing ? 'bg-gray-50' : 'hospital-input'}
                          />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </form>
              </Card>
            </TabsContent>
            
            <TabsContent value="medical">
              <Card className="hospital-card">
                <CardHeader>
                  <CardTitle>Medical History</CardTitle>
                  <CardDescription>Your medical conditions and allergies</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <h3 className="font-medium mb-3">Conditions</h3>
                    {medicalHistory.length > 0 ? (
                      <div className="space-y-2">
                        {medicalHistory.map((condition, index) => (
                          <div 
                            key={index} 
                            className="p-3 border rounded-lg flex justify-between items-center"
                          >
                            <div>
                              <span>{condition}</span>
                            </div>
                            <Badge variant="outline">Active</Badge>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-gray-500">No medical conditions recorded</p>
                    )}
                  </div>
                  
                  <div className="border-t pt-4">
                    <h3 className="font-medium mb-3">Allergies</h3>
                    <div className="p-3 border rounded-lg">
                      <p className="text-sm text-gray-500">No allergies recorded</p>
                    </div>
                  </div>
                  
                  <div className="border-t pt-4">
                    <h3 className="font-medium mb-3">Additional Notes</h3>
                    <Textarea 
                      placeholder="Add any additional information about your medical history..." 
                      className="hospital-input"
                    />
                    <div className="mt-4 flex justify-end">
                      <Button>Save Notes</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="security">
              <Card className="hospital-card">
                <CardHeader>
                  <CardTitle>Security Settings</CardTitle>
                  <CardDescription>Manage your account security</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-full bg-hospital-light-purple/20">
                          <Lock className="h-5 w-5 text-hospital-purple" />
                        </div>
                        <div>
                          <h4 className="font-medium">Password</h4>
                          <p className="text-sm text-gray-500">Update your password</p>
                        </div>
                      </div>
                      <Button variant="outline">Change</Button>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-full bg-hospital-light-purple/20">
                          <Bell className="h-5 w-5 text-hospital-purple" />
                        </div>
                        <div>
                          <h4 className="font-medium">Notifications</h4>
                          <p className="text-sm text-gray-500">Manage your notifications</p>
                        </div>
                      </div>
                      <Button variant="outline">Settings</Button>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-full bg-hospital-light-purple/20">
                          <Shield className="h-5 w-5 text-hospital-purple" />
                        </div>
                        <div>
                          <h4 className="font-medium">Privacy</h4>
                          <p className="text-sm text-gray-500">Manage your privacy settings</p>
                        </div>
                      </div>
                      <Button variant="outline">Configure</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default PatientProfile;
