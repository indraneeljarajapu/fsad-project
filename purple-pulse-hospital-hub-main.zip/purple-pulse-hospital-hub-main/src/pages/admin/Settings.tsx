
import { useState } from 'react';
import { Settings, Users, Building, Layers, Bell, Shield, Database, Info, Save } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';

const AdminSettings = () => {
  const [hospitalSettings, setHospitalSettings] = useState({
    name: 'MediCare General Hospital',
    address: '123 Hospital Road, Healthcare City, USA',
    contactNumber: '(555) 123-4567',
    email: 'info@medicare-hospital.com',
    website: 'www.medicare-hospital.com',
    taxId: 'TAX-12345678',
    timezone: 'America/New_York',
    currency: 'USD',
  });
  
  const [securitySettings, setSecuritySettings] = useState({
    twoFactorAuth: false,
    passwordExpiry: '90',
    sessionTimeout: '30',
    dataEncryption: true,
    auditLogging: true,
  });
  
  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    smsNotifications: true,
    appointmentReminders: true,
    systemAlerts: true,
  });
  
  const handleHospitalChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setHospitalSettings(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSecuritySwitchChange = (name: string, checked: boolean) => {
    setSecuritySettings(prev => ({ ...prev, [name]: checked }));
  };
  
  const handleSecurityInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setSecuritySettings(prev => ({ ...prev, [name]: value }));
  };
  
  const handleNotificationSwitchChange = (name: string, checked: boolean) => {
    setNotificationSettings(prev => ({ ...prev, [name]: checked }));
  };
  
  const handleSaveSettings = (section: string) => {
    // In a real app, this would save to the database
    toast.success(`${section} settings saved successfully!`);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Hospital Settings</h1>
        <p className="text-muted-foreground">Configure hospital settings and preferences</p>
      </div>
      
      <Tabs defaultValue="general">
        <div className="border-b">
          <TabsList className="h-auto p-0">
            <TabsTrigger 
              value="general" 
              className="data-[state=active]:bg-background rounded-none border-b-2 border-transparent data-[state=active]:border-hospital-purple px-4 pb-3 pt-2"
            >
              <Building className="h-4 w-4 mr-2" />
              General
            </TabsTrigger>
            <TabsTrigger 
              value="departments" 
              className="data-[state=active]:bg-background rounded-none border-b-2 border-transparent data-[state=active]:border-hospital-purple px-4 pb-3 pt-2"
            >
              <Layers className="h-4 w-4 mr-2" />
              Departments
            </TabsTrigger>
            <TabsTrigger 
              value="users" 
              className="data-[state=active]:bg-background rounded-none border-b-2 border-transparent data-[state=active]:border-hospital-purple px-4 pb-3 pt-2"
            >
              <Users className="h-4 w-4 mr-2" />
              User Management
            </TabsTrigger>
            <TabsTrigger 
              value="notifications" 
              className="data-[state=active]:bg-background rounded-none border-b-2 border-transparent data-[state=active]:border-hospital-purple px-4 pb-3 pt-2"
            >
              <Bell className="h-4 w-4 mr-2" />
              Notifications
            </TabsTrigger>
            <TabsTrigger 
              value="security" 
              className="data-[state=active]:bg-background rounded-none border-b-2 border-transparent data-[state=active]:border-hospital-purple px-4 pb-3 pt-2"
            >
              <Shield className="h-4 w-4 mr-2" />
              Security
            </TabsTrigger>
          </TabsList>
        </div>
        
        <TabsContent value="general" className="mt-6 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Hospital Information</CardTitle>
              <CardDescription>Basic information about your hospital</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="name">Hospital Name</Label>
                  <Input 
                    id="name" 
                    name="name" 
                    value={hospitalSettings.name} 
                    onChange={handleHospitalChange} 
                    className="hospital-input"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Hospital Email</Label>
                  <Input 
                    id="email" 
                    name="email" 
                    type="email" 
                    value={hospitalSettings.email} 
                    onChange={handleHospitalChange} 
                    className="hospital-input"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="contactNumber">Contact Number</Label>
                  <Input 
                    id="contactNumber" 
                    name="contactNumber" 
                    value={hospitalSettings.contactNumber} 
                    onChange={handleHospitalChange} 
                    className="hospital-input"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="website">Website</Label>
                  <Input 
                    id="website" 
                    name="website" 
                    value={hospitalSettings.website} 
                    onChange={handleHospitalChange} 
                    className="hospital-input"
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="address">Address</Label>
                  <Textarea 
                    id="address" 
                    name="address" 
                    value={hospitalSettings.address} 
                    onChange={handleHospitalChange} 
                    className="hospital-input"
                  />
                </div>
              </div>
              
              <div className="border-t pt-6">
                <h3 className="text-lg font-medium mb-4">System Settings</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="timezone">Timezone</Label>
                    <Select 
                      value={hospitalSettings.timezone} 
                      onValueChange={(value) => 
                        setHospitalSettings(prev => ({ ...prev, timezone: value }))
                      }
                    >
                      <SelectTrigger className="hospital-input">
                        <SelectValue placeholder="Select timezone" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="America/New_York">Eastern Time (ET)</SelectItem>
                        <SelectItem value="America/Chicago">Central Time (CT)</SelectItem>
                        <SelectItem value="America/Denver">Mountain Time (MT)</SelectItem>
                        <SelectItem value="America/Los_Angeles">Pacific Time (PT)</SelectItem>
                        <SelectItem value="Europe/London">London (GMT)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="currency">Currency</Label>
                    <Select 
                      value={hospitalSettings.currency} 
                      onValueChange={(value) => 
                        setHospitalSettings(prev => ({ ...prev, currency: value }))
                      }
                    >
                      <SelectTrigger className="hospital-input">
                        <SelectValue placeholder="Select currency" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="USD">US Dollar ($)</SelectItem>
                        <SelectItem value="EUR">Euro (€)</SelectItem>
                        <SelectItem value="GBP">British Pound (£)</SelectItem>
                        <SelectItem value="CAD">Canadian Dollar (C$)</SelectItem>
                        <SelectItem value="JPY">Japanese Yen (¥)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end">
                <Button 
                  onClick={() => handleSaveSettings('General')} 
                  className="hospital-gradient"
                >
                  <Save className="mr-2 h-4 w-4" />
                  Save Settings
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>About Hospital</CardTitle>
              <CardDescription>Description and mission statement</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="about">About</Label>
                  <Textarea 
                    id="about" 
                    rows={4} 
                    placeholder="Enter information about your hospital..."
                    className="hospital-input"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="mission">Mission Statement</Label>
                  <Textarea 
                    id="mission" 
                    rows={3} 
                    placeholder="Enter your hospital's mission statement..."
                    className="hospital-input"
                  />
                </div>
                <div className="flex justify-end">
                  <Button className="hospital-gradient">Save About Information</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="departments" className="mt-6 space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Departments</CardTitle>
                <CardDescription>Manage hospital departments</CardDescription>
              </div>
              <Button>Add Department</Button>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left">
                  <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                    <tr>
                      <th className="px-6 py-3">Department Name</th>
                      <th className="px-6 py-3">Head Doctor</th>
                      <th className="px-6 py-3">Staff Count</th>
                      <th className="px-6 py-3">Status</th>
                      <th className="px-6 py-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    <tr className="hover:bg-gray-50">
                      <td className="px-6 py-4 font-medium">Cardiology</td>
                      <td className="px-6 py-4">Dr. Jane Smith</td>
                      <td className="px-6 py-4">12</td>
                      <td className="px-6 py-4">
                        <span className="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800">
                          Active
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm">Edit</Button>
                          <Button variant="outline" size="sm">View</Button>
                        </div>
                      </td>
                    </tr>
                    <tr className="hover:bg-gray-50">
                      <td className="px-6 py-4 font-medium">Neurology</td>
                      <td className="px-6 py-4">Dr. Michael Johnson</td>
                      <td className="px-6 py-4">8</td>
                      <td className="px-6 py-4">
                        <span className="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800">
                          Active
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm">Edit</Button>
                          <Button variant="outline" size="sm">View</Button>
                        </div>
                      </td>
                    </tr>
                    <tr className="hover:bg-gray-50">
                      <td className="px-6 py-4 font-medium">Pediatrics</td>
                      <td className="px-6 py-4">Dr. Emily Wilson</td>
                      <td className="px-6 py-4">10</td>
                      <td className="px-6 py-4">
                        <span className="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800">
                          Active
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm">Edit</Button>
                          <Button variant="outline" size="sm">View</Button>
                        </div>
                      </td>
                    </tr>
                    <tr className="hover:bg-gray-50">
                      <td className="px-6 py-4 font-medium">Orthopedics</td>
                      <td className="px-6 py-4">Dr. Robert Clark</td>
                      <td className="px-6 py-4">7</td>
                      <td className="px-6 py-4">
                        <span className="px-2 py-1 text-xs rounded-full bg-yellow-100 text-yellow-800">
                          Understaffed
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm">Edit</Button>
                          <Button variant="outline" size="sm">View</Button>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="users" className="mt-6 space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>User Management</CardTitle>
                <CardDescription>Manage system users and permissions</CardDescription>
              </div>
              <Button>Add User</Button>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left">
                  <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                    <tr>
                      <th className="px-6 py-3">Name</th>
                      <th className="px-6 py-3">Email</th>
                      <th className="px-6 py-3">Role</th>
                      <th className="px-6 py-3">Status</th>
                      <th className="px-6 py-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {mockStaff.map((staff) => (
                      <tr key={staff.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 font-medium">{staff.name}</td>
                        <td className="px-6 py-4">{staff.email}</td>
                        <td className="px-6 py-4 capitalize">{staff.role}</td>
                        <td className="px-6 py-4">
                          <span className="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800">
                            Active
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm">Edit</Button>
                            <Button variant="outline" size="sm">Reset Password</Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Roles and Permissions</CardTitle>
              <CardDescription>Configure system roles and their permissions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 border rounded-md">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-medium">Administrator</h3>
                    <Button variant="outline" size="sm">Edit Role</Button>
                  </div>
                  <p className="text-sm text-gray-500 mb-2">Full system access with all permissions</p>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-sm">
                    <div className="flex items-center space-x-2">
                      <div className="h-2 w-2 bg-green-500 rounded-full"></div>
                      <span>User Management</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="h-2 w-2 bg-green-500 rounded-full"></div>
                      <span>System Configuration</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="h-2 w-2 bg-green-500 rounded-full"></div>
                      <span>Financial Management</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="h-2 w-2 bg-green-500 rounded-full"></div>
                      <span>Reports & Analytics</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="h-2 w-2 bg-green-500 rounded-full"></div>
                      <span>Patient Records</span>
                    </div>
                  </div>
                </div>
                <div className="p-4 border rounded-md">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-medium">Doctor</h3>
                    <Button variant="outline" size="sm">Edit Role</Button>
                  </div>
                  <p className="text-sm text-gray-500 mb-2">Clinical access with patient management</p>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-sm">
                    <div className="flex items-center space-x-2">
                      <div className="h-2 w-2 bg-green-500 rounded-full"></div>
                      <span>Patient Records</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="h-2 w-2 bg-green-500 rounded-full"></div>
                      <span>Appointment Management</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="h-2 w-2 bg-green-500 rounded-full"></div>
                      <span>Prescription Module</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="h-2 w-2 bg-red-500 rounded-full"></div>
                      <span>Financial Management</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="h-2 w-2 bg-red-500 rounded-full"></div>
                      <span>System Configuration</span>
                    </div>
                  </div>
                </div>
                <div className="p-4 border rounded-md">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-medium">Patient</h3>
                    <Button variant="outline" size="sm">Edit Role</Button>
                  </div>
                  <p className="text-sm text-gray-500 mb-2">Limited access to personal records and appointments</p>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-sm">
                    <div className="flex items-center space-x-2">
                      <div className="h-2 w-2 bg-green-500 rounded-full"></div>
                      <span>Personal Records</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="h-2 w-2 bg-green-500 rounded-full"></div>
                      <span>Appointment Booking</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="h-2 w-2 bg-green-500 rounded-full"></div>
                      <span>Payment History</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="h-2 w-2 bg-red-500 rounded-full"></div>
                      <span>Other Patient Records</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="h-2 w-2 bg-red-500 rounded-full"></div>
                      <span>System Access</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="notifications" className="mt-6 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
              <CardDescription>Configure system notifications and alerts</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex flex-row items-center justify-between space-x-2">
                  <div className="space-y-0.5">
                    <Label htmlFor="emailNotifications">Email Notifications</Label>
                    <p className="text-sm text-muted-foreground">
                      Receive notifications via email
                    </p>
                  </div>
                  <Switch 
                    id="emailNotifications" 
                    checked={notificationSettings.emailNotifications} 
                    onCheckedChange={(checked) => handleNotificationSwitchChange('emailNotifications', checked)}
                  />
                </div>
                
                <div className="flex flex-row items-center justify-between space-x-2">
                  <div className="space-y-0.5">
                    <Label htmlFor="smsNotifications">SMS Notifications</Label>
                    <p className="text-sm text-muted-foreground">
                      Receive notifications via text message
                    </p>
                  </div>
                  <Switch 
                    id="smsNotifications" 
                    checked={notificationSettings.smsNotifications} 
                    onCheckedChange={(checked) => handleNotificationSwitchChange('smsNotifications', checked)}
                  />
                </div>
                
                <div className="flex flex-row items-center justify-between space-x-2">
                  <div className="space-y-0.5">
                    <Label htmlFor="appointmentReminders">Appointment Reminders</Label>
                    <p className="text-sm text-muted-foreground">
                      Send reminders for upcoming appointments
                    </p>
                  </div>
                  <Switch 
                    id="appointmentReminders" 
                    checked={notificationSettings.appointmentReminders} 
                    onCheckedChange={(checked) => handleNotificationSwitchChange('appointmentReminders', checked)}
                  />
                </div>
                
                <div className="flex flex-row items-center justify-between space-x-2">
                  <div className="space-y-0.5">
                    <Label htmlFor="systemAlerts">System Alerts</Label>
                    <p className="text-sm text-muted-foreground">
                      Receive alerts for system events and issues
                    </p>
                  </div>
                  <Switch 
                    id="systemAlerts" 
                    checked={notificationSettings.systemAlerts} 
                    onCheckedChange={(checked) => handleNotificationSwitchChange('systemAlerts', checked)}
                  />
                </div>
              </div>
              
              <div className="border-t pt-6">
                <h3 className="text-lg font-medium mb-4">Email Configuration</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="smtpServer">SMTP Server</Label>
                    <Input 
                      id="smtpServer" 
                      placeholder="smtp.example.com" 
                      className="hospital-input"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="smtpPort">SMTP Port</Label>
                    <Input 
                      id="smtpPort" 
                      placeholder="587" 
                      className="hospital-input"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="smtpUsername">SMTP Username</Label>
                    <Input 
                      id="smtpUsername" 
                      placeholder="username@example.com" 
                      className="hospital-input"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="smtpPassword">SMTP Password</Label>
                    <Input 
                      id="smtpPassword" 
                      type="password" 
                      placeholder="••••••••" 
                      className="hospital-input"
                    />
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end">
                <Button 
                  onClick={() => handleSaveSettings('Notification')} 
                  className="hospital-gradient"
                >
                  <Save className="mr-2 h-4 w-4" />
                  Save Notification Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="security" className="mt-6 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Security Settings</CardTitle>
              <CardDescription>Configure system security and access controls</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex flex-row items-center justify-between space-x-2">
                  <div className="space-y-0.5">
                    <Label htmlFor="twoFactorAuth">Two-Factor Authentication</Label>
                    <p className="text-sm text-muted-foreground">
                      Require two-factor authentication for all users
                    </p>
                  </div>
                  <Switch 
                    id="twoFactorAuth" 
                    checked={securitySettings.twoFactorAuth} 
                    onCheckedChange={(checked) => handleSecuritySwitchChange('twoFactorAuth', checked)}
                  />
                </div>
                
                <div className="flex flex-row items-center justify-between space-x-2">
                  <div className="space-y-0.5">
                    <Label htmlFor="dataEncryption">Data Encryption</Label>
                    <p className="text-sm text-muted-foreground">
                      Enable encryption for sensitive patient data
                    </p>
                  </div>
                  <Switch 
                    id="dataEncryption" 
                    checked={securitySettings.dataEncryption} 
                    onCheckedChange={(checked) => handleSecuritySwitchChange('dataEncryption', checked)}
                  />
                </div>
                
                <div className="flex flex-row items-center justify-between space-x-2">
                  <div className="space-y-0.5">
                    <Label htmlFor="auditLogging">Audit Logging</Label>
                    <p className="text-sm text-muted-foreground">
                      Keep logs of all system access and changes
                    </p>
                  </div>
                  <Switch 
                    id="auditLogging" 
                    checked={securitySettings.auditLogging} 
                    onCheckedChange={(checked) => handleSecuritySwitchChange('auditLogging', checked)}
                  />
                </div>
              </div>
              
              <div className="border-t pt-6">
                <h3 className="text-lg font-medium mb-4">Password Policies</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="passwordExpiry">Password Expiration (days)</Label>
                    <Input 
                      id="passwordExpiry" 
                      name="passwordExpiry"
                      type="number" 
                      value={securitySettings.passwordExpiry} 
                      onChange={handleSecurityInputChange}
                      className="hospital-input"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="sessionTimeout">Session Timeout (minutes)</Label>
                    <Input 
                      id="sessionTimeout" 
                      name="sessionTimeout"
                      type="number" 
                      value={securitySettings.sessionTimeout} 
                      onChange={handleSecurityInputChange}
                      className="hospital-input"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="minimumLength">Minimum Password Length</Label>
                    <Input 
                      id="minimumLength" 
                      type="number" 
                      placeholder="8" 
                      className="hospital-input"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="passwordComplexity">Password Complexity</Label>
                    <Select defaultValue="medium">
                      <SelectTrigger className="hospital-input">
                        <SelectValue placeholder="Select complexity" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low - Letters and numbers</SelectItem>
                        <SelectItem value="medium">Medium - Letters, numbers, and special characters</SelectItem>
                        <SelectItem value="high">High - Letters, numbers, special chars & min length</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end">
                <Button 
                  onClick={() => handleSaveSettings('Security')} 
                  className="hospital-gradient"
                >
                  <Save className="mr-2 h-4 w-4" />
                  Save Security Settings
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Backup & Recovery</CardTitle>
              <CardDescription>Configure system backup settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-medium">Automatic Backups</h3>
                  <p className="text-sm text-gray-500">System is backed up daily at midnight</p>
                </div>
                <Button className="hospital-gradient">Run Backup Now</Button>
              </div>
              
              <div className="border-t pt-4">
                <h3 className="font-medium mb-2">Backup History</h3>
                <div className="space-y-2">
                  <div className="p-3 border rounded-md flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <Database className="h-4 w-4 text-gray-400" />
                      <div>
                        <p className="font-medium">Full System Backup</p>
                        <p className="text-xs text-gray-500">2025-05-10 00:00:00</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">Restore</Button>
                  </div>
                  <div className="p-3 border rounded-md flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <Database className="h-4 w-4 text-gray-400" />
                      <div>
                        <p className="font-medium">Full System Backup</p>
                        <p className="text-xs text-gray-500">2025-05-09 00:00:00</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">Restore</Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <div className="flex items-center p-4 border rounded-lg bg-yellow-50 border-yellow-200">
        <Info className="h-5 w-5 text-yellow-600 mr-2" />
        <div>
          <h4 className="font-medium text-yellow-800">Reminder</h4>
          <p className="text-sm text-yellow-700">
            Changes to system settings may require users to log out and log back in to take effect.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AdminSettings;
