
import { Link } from 'react-router-dom';
import { Users, User, Calendar, Clock, Settings, DollarSign, Building, Activity } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { mockDoctors, mockPatients, mockAppointments, mockStaff } from '@/lib/mockData';
import { AreaChart, Area, BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// Chart data - simplified for example
const revenueData = [
  { name: 'Jan', amount: 4000 },
  { name: 'Feb', amount: 3000 },
  { name: 'Mar', amount: 5000 },
  { name: 'Apr', amount: 4000 },
  { name: 'May', amount: 6000 },
  { name: 'Jun', amount: 5500 },
];

const patientData = [
  { name: 'Mon', value: 15 },
  { name: 'Tue', value: 22 },
  { name: 'Wed', value: 18 },
  { name: 'Thu', value: 25 },
  { name: 'Fri', value: 20 },
  { name: 'Sat', value: 12 },
  { name: 'Sun', value: 8 },
];

const departmentData = [
  { name: 'Cardiology', patients: 35 },
  { name: 'Neurology', patients: 28 },
  { name: 'Pediatrics', patients: 42 },
  { name: 'Orthopedics', patients: 22 },
  { name: 'Dermatology', patients: 15 },
];

const AdminDashboard = () => {
  // Count doctors and patients
  const doctorCount = mockStaff.filter(staff => staff.role === 'doctor').length;
  const patientCount = mockPatients.length;
  
  // Count appointments
  const appointmentCount = mockAppointments.length;
  
  // Calculate pending payments
  const pendingPayments = mockAppointments.filter(
    appointment => appointment.paymentStatus === 'pending'
  ).length;

  return (
    <div className="space-y-6">
      {/* Quick Stats Cards */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="hospital-card">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Patients</CardTitle>
            <User className="h-4 w-4 text-hospital-purple" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{patientCount}</div>
            <p className="text-xs text-muted-foreground">
              +6 new this week
            </p>
          </CardContent>
          <CardFooter className="p-2">
            <Link 
              to="/admin-patients" 
              className="text-xs text-hospital-purple hover:underline w-full text-right"
            >
              View details
            </Link>
          </CardFooter>
        </Card>

        <Card className="hospital-card">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Staff</CardTitle>
            <Users className="h-4 w-4 text-hospital-purple" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{doctorCount + 1}</div> {/* +1 for admin */}
            <p className="text-xs text-muted-foreground">
              Doctors: {doctorCount}, Admin: 1
            </p>
          </CardContent>
          <CardFooter className="p-2">
            <Link 
              to="/admin-staff" 
              className="text-xs text-hospital-purple hover:underline w-full text-right"
            >
              Manage staff
            </Link>
          </CardFooter>
        </Card>

        <Card className="hospital-card">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Appointments</CardTitle>
            <Calendar className="h-4 w-4 text-hospital-purple" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{appointmentCount}</div>
            <p className="text-xs text-muted-foreground">
              12 scheduled for today
            </p>
          </CardContent>
          <CardFooter className="p-2">
            <span
              className="text-xs text-hospital-purple hover:underline w-full text-right cursor-pointer"
            >
              View calendar
            </span>
          </CardFooter>
        </Card>

        <Card className="hospital-card">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Pending Payments</CardTitle>
            <DollarSign className="h-4 w-4 text-hospital-purple" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pendingPayments}</div>
            <p className="text-xs text-muted-foreground">
              $1,250 pending amount
            </p>
          </CardContent>
          <CardFooter className="p-2">
            <span
              className="text-xs text-hospital-purple hover:underline w-full text-right cursor-pointer"
            >
              Process payments
            </span>
          </CardFooter>
        </Card>
      </div>

      {/* Analytics Tabs */}
      <Card className="hospital-card">
        <CardHeader>
          <CardTitle>Hospital Analytics</CardTitle>
          <CardDescription>Overview of hospital performance and metrics</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="patients">
            <TabsList className="mb-6">
              <TabsTrigger value="patients">Patients</TabsTrigger>
              <TabsTrigger value="revenue">Revenue</TabsTrigger>
              <TabsTrigger value="departments">Departments</TabsTrigger>
            </TabsList>
            
            <TabsContent value="patients">
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart
                    data={patientData}
                    margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient id="colorPatients" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#9b87f5" stopOpacity={0.8} />
                        <stop offset="95%" stopColor="#9b87f5" stopOpacity={0.1} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} />
                    <YAxis axisLine={false} tickLine={false} />
                    <Tooltip />
                    <Area 
                      type="monotone" 
                      dataKey="value" 
                      stroke="#9b87f5" 
                      fillOpacity={1} 
                      fill="url(#colorPatients)" 
                      name="Patients"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <div className="text-center text-sm text-gray-500 mt-2">
                Patient visits per day this week
              </div>
            </TabsContent>
            
            <TabsContent value="revenue">
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={revenueData}
                    margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} />
                    <YAxis axisLine={false} tickLine={false} />
                    <Tooltip formatter={(value) => [`$${value}`, 'Revenue']} />
                    <Line 
                      type="monotone" 
                      dataKey="amount" 
                      stroke="#9b87f5" 
                      strokeWidth={2}
                      dot={{ r: 4, fill: '#9b87f5' }}
                      activeDot={{ r: 6, fill: '#9b87f5' }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <div className="text-center text-sm text-gray-500 mt-2">
                Revenue trend for the past 6 months
              </div>
            </TabsContent>
            
            <TabsContent value="departments">
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={departmentData}
                    margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} />
                    <YAxis axisLine={false} tickLine={false} />
                    <Tooltip />
                    <Bar 
                      dataKey="patients" 
                      fill="#9b87f5" 
                      barSize={40} 
                      radius={[4, 4, 0, 0]} 
                      name="Patients"
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="text-center text-sm text-gray-500 mt-2">
                Patient distribution by department
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Administration Quick Links */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card className="hospital-card">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-full bg-hospital-light-purple/20">
                <Users className="h-5 w-5 text-hospital-purple" />
              </div>
              <CardTitle>Staff Management</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="pb-3">
            <ul className="space-y-2 text-sm">
              <li className="flex justify-between">
                <span>Total Doctors</span>
                <span className="font-medium">{doctorCount}</span>
              </li>
              <li className="flex justify-between">
                <span>Active Doctors</span>
                <span className="font-medium">{doctorCount}</span>
              </li>
              <li className="flex justify-between">
                <span>On Leave</span>
                <span className="font-medium">0</span>
              </li>
              <li className="flex justify-between">
                <span>Admin Staff</span>
                <span className="font-medium">1</span>
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button asChild variant="outline" className="w-full">
              <Link to="/admin-staff">Manage Staff</Link>
            </Button>
          </CardFooter>
        </Card>

        <Card className="hospital-card">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-full bg-hospital-light-purple/20">
                <Building className="h-5 w-5 text-hospital-purple" />
              </div>
              <CardTitle>Facility Management</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="pb-3">
            <ul className="space-y-2 text-sm">
              <li className="flex justify-between">
                <span>Total Rooms</span>
                <span className="font-medium">42</span>
              </li>
              <li className="flex justify-between">
                <span>Occupied Rooms</span>
                <span className="font-medium">28</span>
              </li>
              <li className="flex justify-between">
                <span>Available Rooms</span>
                <span className="font-medium">14</span>
              </li>
              <li className="flex justify-between">
                <span>Maintenance Needed</span>
                <span className="font-medium">3</span>
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full">Facility Dashboard</Button>
          </CardFooter>
        </Card>

        <Card className="hospital-card">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-full bg-hospital-light-purple/20">
                <Settings className="h-5 w-5 text-hospital-purple" />
              </div>
              <CardTitle>Quick Actions</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="pb-3">
            <div className="grid grid-cols-2 gap-2">
              <Button variant="outline" className="text-sm h-auto py-2">Add Doctor</Button>
              <Button variant="outline" className="text-sm h-auto py-2">Add Patient</Button>
              <Button variant="outline" className="text-sm h-auto py-2">View Schedule</Button>
              <Button variant="outline" className="text-sm h-auto py-2">Generate Report</Button>
              <Button variant="outline" className="text-sm h-auto py-2 col-span-2">
                System Settings
              </Button>
            </div>
          </CardContent>
          <CardFooter>
            <Button asChild className="w-full hospital-gradient">
              <Link to="/admin-settings">Hospital Settings</Link>
            </Button>
          </CardFooter>
        </Card>
      </div>
      
      {/* Hospital Statistics & Status */}
      <Card className="hospital-card">
        <CardHeader>
          <CardTitle>Hospital Status</CardTitle>
          <CardDescription>Real-time metrics and status</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <Activity className="h-4 w-4 text-hospital-purple" />
                  <span className="text-sm font-medium">Bed Occupancy</span>
                </div>
                <span className="text-sm font-bold">68%</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full bg-hospital-purple rounded-full" style={{ width: '68%' }} />
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-hospital-purple" />
                  <span className="text-sm font-medium">Avg Wait Time</span>
                </div>
                <span className="text-sm font-bold">28 min</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full bg-hospital-purple rounded-full" style={{ width: '45%' }} />
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-hospital-purple" />
                  <span className="text-sm font-medium">Staff Attendance</span>
                </div>
                <span className="text-sm font-bold">92%</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full bg-hospital-purple rounded-full" style={{ width: '92%' }} />
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <DollarSign className="h-4 w-4 text-hospital-purple" />
                  <span className="text-sm font-medium">Budget Utilized</span>
                </div>
                <span className="text-sm font-bold">78%</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full bg-hospital-purple rounded-full" style={{ width: '78%' }} />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminDashboard;
