
import { useState } from 'react';
import { Search, Plus, Edit, Trash2, User, Mail, Phone, UserCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { Label } from '@/components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { toast } from 'sonner';
import { mockStaff } from '@/lib/mockData';
import { UserRole } from '@/contexts/AuthContext';

const AdminStaff = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddingStaff, setIsAddingStaff] = useState(false);
  const [staffToEdit, setStaffToEdit] = useState<string | null>(null);
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    role: 'doctor' as UserRole,
    phone: '',
    department: '',
    qualifications: '',
  });
  
  // Filter staff based on search
  const filteredStaff = mockStaff.filter(staff =>
    staff.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    staff.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    staff.role.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const doctors = filteredStaff.filter(staff => staff.role === 'doctor');
  const admins = filteredStaff.filter(staff => staff.role === 'admin');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleAddStaff = () => {
    // Reset form data
    setFormData({
      name: '',
      email: '',
      role: 'doctor',
      phone: '',
      department: '',
      qualifications: '',
    });
    setStaffToEdit(null);
    setIsAddingStaff(true);
  };

  const handleEditStaff = (staffId: string) => {
    const staff = mockStaff.find(s => s.id === staffId);
    if (!staff) return;
    
    setFormData({
      name: staff.name,
      email: staff.email,
      role: staff.role,
      phone: '',
      department: '',
      qualifications: '',
    });
    setStaffToEdit(staffId);
    setIsAddingStaff(true);
  };

  const handleDeleteStaff = (staffId: string) => {
    // In a real app, this would delete from the database
    toast.success('Staff member removed successfully!');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // In a real app, this would save to the database
    if (staffToEdit) {
      toast.success(`Staff member "${formData.name}" updated successfully!`);
    } else {
      toast.success(`New staff member "${formData.name}" added successfully!`);
    }
    
    setIsAddingStaff(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Staff Management</h1>
          <p className="text-muted-foreground">Manage hospital staff and permissions</p>
        </div>
        
        <Button onClick={handleAddStaff} className="hospital-gradient">
          <Plus className="mr-2 h-4 w-4" />
          Add New Staff
        </Button>
      </div>
      
      <div className="flex flex-col md:flex-row md:justify-between gap-4">
        <div className="relative w-full md:w-64">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            type="search"
            placeholder="Search staff..."
            className="pl-8 hospital-input"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">All Staff</TabsTrigger>
          <TabsTrigger value="doctors">Doctors</TabsTrigger>
          <TabsTrigger value="admins">Admin Staff</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Staff Directory</CardTitle>
              <CardDescription>
                Total staff: {filteredStaff.length}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left">
                  <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                    <tr>
                      <th className="px-6 py-3">Name</th>
                      <th className="px-6 py-3">Role</th>
                      <th className="px-6 py-3">Email</th>
                      <th className="px-6 py-3">Status</th>
                      <th className="px-6 py-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {filteredStaff.map((staff) => (
                      <tr key={staff.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 font-medium">
                          <div className="flex items-center">
                            <div className="h-8 w-8 rounded-full bg-hospital-light-purple/30 flex items-center justify-center mr-3">
                              <User className="h-4 w-4 text-hospital-purple" />
                            </div>
                            {staff.name}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <Badge className={
                            staff.role === 'doctor' 
                              ? 'bg-blue-100 text-blue-700' 
                              : 'bg-purple-100 text-purple-700'
                          }>
                            {staff.role.charAt(0).toUpperCase() + staff.role.slice(1)}
                          </Badge>
                        </td>
                        <td className="px-6 py-4">{staff.email}</td>
                        <td className="px-6 py-4">
                          <div className="flex items-center">
                            <span className="w-2 h-2 rounded-full bg-green-500 mr-2"></span>
                            Active
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                Actions
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => handleEditStaff(staff.id)}>
                                <Edit className="mr-2 h-4 w-4" />
                                Edit
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleDeleteStaff(staff.id)}>
                                <Trash2 className="mr-2 h-4 w-4" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                
                {filteredStaff.length === 0 && (
                  <div className="text-center py-8">
                    <p className="text-gray-500">No staff members found matching your search</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="doctors" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Doctors</CardTitle>
              <CardDescription>
                Total doctors: {doctors.length}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {doctors.map((doctor) => (
                  <div
                    key={doctor.id}
                    className="border rounded-lg p-4 hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center mb-3">
                      <div className="h-10 w-10 rounded-full bg-hospital-light-purple/30 flex items-center justify-center mr-3">
                        <User className="h-5 w-5 text-hospital-purple" />
                      </div>
                      <div>
                        <p className="font-medium">{doctor.name}</p>
                        <p className="text-xs text-gray-500">Cardiologist</p>
                      </div>
                    </div>

                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Mail className="h-4 w-4 text-gray-400" />
                        <span>{doctor.email}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Phone className="h-4 w-4 text-gray-400" />
                        <span>(555) 123-4567</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <UserCheck className="h-4 w-4 text-gray-400" />
                        <span className="flex items-center">
                          <span className="w-2 h-2 rounded-full bg-green-500 mr-1"></span>
                          Active
                        </span>
                      </div>
                    </div>

                    <div className="mt-4 flex justify-end gap-2">
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="text-hospital-purple"
                        onClick={() => handleEditStaff(doctor.id)}
                      >
                        <Edit className="h-4 w-4 mr-1" />
                        Edit
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
              
              {doctors.length === 0 && (
                <div className="text-center py-8">
                  <p className="text-gray-500">No doctors found matching your search</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="admins" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Admin Staff</CardTitle>
              <CardDescription>
                Total admin staff: {admins.length}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {admins.map((admin) => (
                  <div
                    key={admin.id}
                    className="border rounded-lg p-4 hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center mb-3">
                      <div className="h-10 w-10 rounded-full bg-hospital-light-purple/30 flex items-center justify-center mr-3">
                        <User className="h-5 w-5 text-hospital-purple" />
                      </div>
                      <div>
                        <p className="font-medium">{admin.name}</p>
                        <Badge className="bg-purple-100 text-purple-700 mt-1">
                          Administrator
                        </Badge>
                      </div>
                    </div>

                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Mail className="h-4 w-4 text-gray-400" />
                        <span>{admin.email}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Phone className="h-4 w-4 text-gray-400" />
                        <span>(555) 789-0123</span>
                      </div>
                    </div>

                    <div className="mt-4 flex justify-end gap-2">
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="text-hospital-purple"
                        onClick={() => handleEditStaff(admin.id)}
                      >
                        <Edit className="h-4 w-4 mr-1" />
                        Edit
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
              
              {admins.length === 0 && (
                <div className="text-center py-8">
                  <p className="text-gray-500">No admin staff found matching your search</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Add/Edit Staff Dialog */}
      <Dialog open={isAddingStaff} onOpenChange={setIsAddingStaff}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{staffToEdit ? 'Edit Staff Member' : 'Add New Staff Member'}</DialogTitle>
            <DialogDescription>
              {staffToEdit 
                ? 'Update staff member information' 
                : 'Enter details to add a new staff member'
              }
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input 
                id="name" 
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                required 
                className="hospital-input"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input 
                id="email" 
                name="email"
                type="email"
                value={formData.email}
                onChange={handleInputChange}
                required 
                className="hospital-input"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="role">Role</Label>
              <Select 
                name="role" 
                value={formData.role} 
                onValueChange={(value) => setFormData(prev => ({ ...prev, role: value as UserRole }))}
              >
                <SelectTrigger className="hospital-input">
                  <SelectValue placeholder="Select a role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="doctor">Doctor</SelectItem>
                  <SelectItem value="admin">Administrator</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input 
                id="phone" 
                name="phone"
                value={formData.phone}
                onChange={handleInputChange}
                className="hospital-input"
              />
            </div>
            
            {formData.role === 'doctor' && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="department">Department</Label>
                  <Select 
                    name="department" 
                    value={formData.department} 
                    onValueChange={(value) => setFormData(prev => ({ ...prev, department: value }))}
                  >
                    <SelectTrigger className="hospital-input">
                      <SelectValue placeholder="Select a department" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cardiology">Cardiology</SelectItem>
                      <SelectItem value="neurology">Neurology</SelectItem>
                      <SelectItem value="pediatrics">Pediatrics</SelectItem>
                      <SelectItem value="orthopedics">Orthopedics</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="qualifications">Qualifications</Label>
                  <Input 
                    id="qualifications" 
                    name="qualifications"
                    value={formData.qualifications}
                    onChange={handleInputChange}
                    placeholder="MD, PhD, etc."
                    className="hospital-input"
                  />
                </div>
              </>
            )}
            
            <DialogFooter>
              <Button
                variant="outline" 
                onClick={() => setIsAddingStaff(false)}
                type="button"
              >
                Cancel
              </Button>
              <Button type="submit" className="hospital-gradient">
                {staffToEdit ? 'Update Staff' : 'Add Staff'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminStaff;
