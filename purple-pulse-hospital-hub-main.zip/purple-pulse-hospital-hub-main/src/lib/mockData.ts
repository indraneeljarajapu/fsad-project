
import { User, UserRole } from '@/contexts/AuthContext';

export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  experience: number;
  avatar: string;
  availability: Array<{
    day: string;
    slots: Array<{
      time: string;
      isAvailable: boolean;
    }>;
  }>;
}

export interface Patient {
  id: string;
  name: string;
  age: number;
  gender: 'male' | 'female' | 'other';
  contactNumber: string;
  email: string;
  medicalHistory?: string[];
}

export interface Appointment {
  id: string;
  patientId: string;
  doctorId: string;
  date: string;
  time: string;
  status: 'scheduled' | 'completed' | 'cancelled';
  paymentStatus: 'pending' | 'paid';
  amount: number;
}

export interface HealthRecord {
  id: string;
  patientId: string;
  doctorId: string;
  date: string;
  diagnosis: string;
  prescription: string;
  notes: string;
}

// Mock Doctors
export const mockDoctors: Doctor[] = [
  {
    id: '1',
    name: 'Dr. Jane Smith',
    specialty: 'Cardiology',
    experience: 8,
    avatar: 'https://i.pravatar.cc/150?img=1',
    availability: [
      {
        day: 'Monday',
        slots: [
          { time: '09:00 AM', isAvailable: true },
          { time: '10:00 AM', isAvailable: true },
          { time: '11:00 AM', isAvailable: false },
          { time: '02:00 PM', isAvailable: true },
          { time: '03:00 PM', isAvailable: true },
        ],
      },
      {
        day: 'Tuesday',
        slots: [
          { time: '09:00 AM', isAvailable: true },
          { time: '10:00 AM', isAvailable: false },
          { time: '11:00 AM', isAvailable: false },
          { time: '02:00 PM', isAvailable: true },
          { time: '03:00 PM', isAvailable: true },
        ],
      },
      {
        day: 'Wednesday',
        slots: [
          { time: '09:00 AM', isAvailable: true },
          { time: '10:00 AM', isAvailable: true },
          { time: '11:00 AM', isAvailable: true },
          { time: '02:00 PM', isAvailable: false },
          { time: '03:00 PM', isAvailable: false },
        ],
      },
      {
        day: 'Thursday',
        slots: [
          { time: '09:00 AM', isAvailable: false },
          { time: '10:00 AM', isAvailable: false },
          { time: '11:00 AM', isAvailable: true },
          { time: '02:00 PM', isAvailable: true },
          { time: '03:00 PM', isAvailable: true },
        ],
      },
      {
        day: 'Friday',
        slots: [
          { time: '09:00 AM', isAvailable: true },
          { time: '10:00 AM', isAvailable: true },
          { time: '11:00 AM', isAvailable: true },
          { time: '02:00 PM', isAvailable: true },
          { time: '03:00 PM', isAvailable: false },
        ],
      },
    ],
  },
  {
    id: '2',
    name: 'Dr. Michael Johnson',
    specialty: 'Neurology',
    experience: 12,
    avatar: 'https://i.pravatar.cc/150?img=4',
    availability: [
      {
        day: 'Monday',
        slots: [
          { time: '09:00 AM', isAvailable: false },
          { time: '10:00 AM', isAvailable: false },
          { time: '11:00 AM', isAvailable: true },
          { time: '02:00 PM', isAvailable: true },
          { time: '03:00 PM', isAvailable: true },
        ],
      },
      {
        day: 'Wednesday',
        slots: [
          { time: '09:00 AM', isAvailable: true },
          { time: '10:00 AM', isAvailable: true },
          { time: '11:00 AM', isAvailable: true },
          { time: '02:00 PM', isAvailable: true },
          { time: '03:00 PM', isAvailable: true },
        ],
      },
      {
        day: 'Friday',
        slots: [
          { time: '09:00 AM', isAvailable: true },
          { time: '10:00 AM', isAvailable: true },
          { time: '11:00 AM', isAvailable: false },
          { time: '02:00 PM', isAvailable: false },
          { time: '03:00 PM', isAvailable: true },
        ],
      },
    ],
  },
  {
    id: '3',
    name: 'Dr. Emily Wilson',
    specialty: 'Pediatrics',
    experience: 5,
    avatar: 'https://i.pravatar.cc/150?img=5',
    availability: [
      {
        day: 'Tuesday',
        slots: [
          { time: '09:00 AM', isAvailable: true },
          { time: '10:00 AM', isAvailable: true },
          { time: '11:00 AM', isAvailable: true },
          { time: '02:00 PM', isAvailable: false },
          { time: '03:00 PM', isAvailable: false },
        ],
      },
      {
        day: 'Thursday',
        slots: [
          { time: '09:00 AM', isAvailable: true },
          { time: '10:00 AM', isAvailable: false },
          { time: '11:00 AM', isAvailable: false },
          { time: '02:00 PM', isAvailable: true },
          { time: '03:00 PM', isAvailable: true },
        ],
      },
    ],
  },
];

// Mock Patients
export const mockPatients: Patient[] = [
  {
    id: '1',
    name: 'John Doe',
    age: 35,
    gender: 'male',
    contactNumber: '(123) 456-7890',
    email: 'john.doe@example.com',
    medicalHistory: ['Hypertension', 'Diabetes Type 2'],
  },
  {
    id: '2',
    name: 'Sarah Williams',
    age: 28,
    gender: 'female',
    contactNumber: '(987) 654-3210',
    email: 'sarah.williams@example.com',
    medicalHistory: ['Asthma'],
  },
  {
    id: '3',
    name: 'Robert Brown',
    age: 45,
    gender: 'male',
    contactNumber: '(555) 123-4567',
    email: 'robert.brown@example.com',
    medicalHistory: ['Heart Disease', 'High Cholesterol'],
  },
  {
    id: '4',
    name: 'Jessica Miller',
    age: 32,
    gender: 'female',
    contactNumber: '(222) 333-4444',
    email: 'jessica.miller@example.com',
    medicalHistory: ['Migraine', 'Anxiety'],
  },
];

// Mock Appointments
export const mockAppointments: Appointment[] = [
  {
    id: '1',
    patientId: '1',
    doctorId: '1',
    date: '2025-05-15',
    time: '09:00 AM',
    status: 'scheduled',
    paymentStatus: 'paid',
    amount: 150,
  },
  {
    id: '2',
    patientId: '1',
    doctorId: '3',
    date: '2025-05-12',
    time: '02:00 PM',
    status: 'scheduled',
    paymentStatus: 'pending',
    amount: 120,
  },
  {
    id: '3',
    patientId: '2',
    doctorId: '2',
    date: '2025-05-10',
    time: '11:00 AM',
    status: 'completed',
    paymentStatus: 'paid',
    amount: 200,
  },
  {
    id: '4',
    patientId: '3',
    doctorId: '1',
    date: '2025-05-20',
    time: '10:00 AM',
    status: 'scheduled',
    paymentStatus: 'pending',
    amount: 150,
  },
  {
    id: '5',
    patientId: '4',
    doctorId: '3',
    date: '2025-05-08',
    time: '09:00 AM',
    status: 'cancelled',
    paymentStatus: 'paid',
    amount: 120,
  },
];

// Mock Health Records
export const mockHealthRecords: HealthRecord[] = [
  {
    id: '1',
    patientId: '1',
    doctorId: '1',
    date: '2025-04-10',
    diagnosis: 'Hypertension, Stage 1',
    prescription: 'Lisinopril 10mg daily',
    notes: 'Patient should monitor blood pressure daily and maintain low sodium diet',
  },
  {
    id: '2',
    patientId: '1',
    doctorId: '2',
    date: '2025-04-20',
    diagnosis: 'Migraine',
    prescription: 'Sumatriptan 50mg as needed',
    notes: 'Patient should avoid triggers like bright lights and loud noises',
  },
  {
    id: '3',
    patientId: '2',
    doctorId: '3',
    date: '2025-04-15',
    diagnosis: 'Upper respiratory infection',
    prescription: 'Amoxicillin 500mg three times daily for 7 days',
    notes: 'Follow up in one week if symptoms persist',
  },
  {
    id: '4',
    patientId: '3',
    doctorId: '1',
    date: '2025-04-25',
    diagnosis: 'Angina',
    prescription: 'Nitroglycerin 0.4mg sublingual as needed',
    notes: 'Referred to cardiologist for further evaluation',
  },
];

// Staff (Doctors and Admin)
export const mockStaff: {id: string; name: string; role: UserRole; email: string}[] = [
  {
    id: '1',
    name: 'Dr. Jane Smith',
    role: 'doctor',
    email: 'doctor@example.com',
  },
  {
    id: '2',
    name: 'Dr. Michael Johnson',
    role: 'doctor',
    email: 'michael@example.com',
  },
  {
    id: '3',
    name: 'Dr. Emily Wilson',
    role: 'doctor',
    email: 'emily@example.com',
  },
  {
    id: '4',
    name: 'Admin User',
    role: 'admin',
    email: 'admin@example.com',
  },
];
