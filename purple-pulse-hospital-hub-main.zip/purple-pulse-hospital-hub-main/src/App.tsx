
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";

// Pages
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";
import AppLayout from "./components/AppLayout";
import ProtectedRoute from "./components/ProtectedRoute";

// Patient Pages
import PatientDashboard from "./pages/patient/Dashboard";
import PatientAppointments from "./pages/patient/Appointments";
import PatientHealthRecords from "./pages/patient/HealthRecords";
import PatientProfile from "./pages/patient/Profile";

// Doctor Pages
import DoctorDashboard from "./pages/doctor/Dashboard";
import DoctorPatients from "./pages/doctor/Patients";
import DoctorShifts from "./pages/doctor/Shifts";
import DoctorProfile from "./pages/doctor/Profile";

// Admin Pages
import AdminDashboard from "./pages/admin/Dashboard";
import AdminStaff from "./pages/admin/Staff";
import AdminSettings from "./pages/admin/Settings";

const queryClient = new QueryClient();

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <AuthProvider>
          <TooltipProvider>
            <Toaster />
            <Sonner />
            <AppRoutes />
          </TooltipProvider>
        </AuthProvider>
      </BrowserRouter>
    </QueryClientProvider>
  );
};

const AppRoutes = () => {
  const { user } = useAuth();

  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/login" element={
        user ? (
          <Navigate 
            to={
              user.role === 'patient' ? '/patient-dashboard' : 
              user.role === 'doctor' ? '/doctor-dashboard' : '/admin-dashboard'
            } 
            replace 
          />
        ) : (
          <Login />
        )
      } />

      {/* Protected Patient Routes */}
      <Route path="/patient-dashboard" element={
        <ProtectedRoute allowedRoles={['patient']}>
          <AppLayout>
            <PatientDashboard />
          </AppLayout>
        </ProtectedRoute>
      } />
      <Route path="/patient-appointments" element={
        <ProtectedRoute allowedRoles={['patient']}>
          <AppLayout>
            <PatientAppointments />
          </AppLayout>
        </ProtectedRoute>
      } />
      <Route path="/patient-records" element={
        <ProtectedRoute allowedRoles={['patient']}>
          <AppLayout>
            <PatientHealthRecords />
          </AppLayout>
        </ProtectedRoute>
      } />
      <Route path="/patient-profile" element={
        <ProtectedRoute allowedRoles={['patient']}>
          <AppLayout>
            <PatientProfile />
          </AppLayout>
        </ProtectedRoute>
      } />

      {/* Protected Doctor Routes */}
      <Route path="/doctor-dashboard" element={
        <ProtectedRoute allowedRoles={['doctor']}>
          <AppLayout>
            <DoctorDashboard />
          </AppLayout>
        </ProtectedRoute>
      } />
      <Route path="/doctor-patients" element={
        <ProtectedRoute allowedRoles={['doctor']}>
          <AppLayout>
            <DoctorPatients />
          </AppLayout>
        </ProtectedRoute>
      } />
      <Route path="/doctor-shifts" element={
        <ProtectedRoute allowedRoles={['doctor']}>
          <AppLayout>
            <DoctorShifts />
          </AppLayout>
        </ProtectedRoute>
      } />
      <Route path="/doctor-profile" element={
        <ProtectedRoute allowedRoles={['doctor']}>
          <AppLayout>
            <DoctorProfile />
          </AppLayout>
        </ProtectedRoute>
      } />

      {/* Protected Admin Routes */}
      <Route path="/admin-dashboard" element={
        <ProtectedRoute allowedRoles={['admin']}>
          <AppLayout>
            <AdminDashboard />
          </AppLayout>
        </ProtectedRoute>
      } />
      <Route path="/admin-staff" element={
        <ProtectedRoute allowedRoles={['admin']}>
          <AppLayout>
            <AdminStaff />
          </AppLayout>
        </ProtectedRoute>
      } />
      <Route path="/admin-settings" element={
        <ProtectedRoute allowedRoles={['admin']}>
          <AppLayout>
            <AdminSettings />
          </AppLayout>
        </ProtectedRoute>
      } />

      {/* Default Redirects */}
      <Route path="/" element={
        user ? (
          <Navigate 
            to={
              user.role === 'patient' ? '/patient-dashboard' : 
              user.role === 'doctor' ? '/doctor-dashboard' : '/admin-dashboard'
            } 
            replace 
          />
        ) : (
          <Navigate to="/login" replace />
        )
      } />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default App;
